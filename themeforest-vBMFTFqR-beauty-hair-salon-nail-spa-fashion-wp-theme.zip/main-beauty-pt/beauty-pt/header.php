<?php
/**
 * The Header for Beauty Theme
 *
 * @package Beauty
 */

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
		<?php endif; ?>

		<?php wp_head(); ?>
	</head>

	<body <?php body_class( BeautyHelpers::add_body_class() ); ?>>
	<div class="boxed-container">

	<header class="site-header">
		<?php get_template_part( 'template-parts/top-bar' ); ?>

		<div class="header__container">
			<div class="container">
				<div class="header<?php echo ( 'center-logo' === get_theme_mod( 'header_layout', 'left-logo' ) ) ? '' : '  header--left-logo'; echo is_active_sidebar( 'navigation-widgets' ) ? '' : '  header--no-nav-widgets'; ?>">
					<!-- Logo and site name -->
					<div class="header__logo">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
							<?php
							$beauty_logo   = get_theme_mod( 'logo_img', false );
							$beauty_logo2x = get_theme_mod( 'logo2x_img', false );

							if ( ! empty( $beauty_logo ) ) :
							?>
								<img src="<?php echo esc_url( $beauty_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" srcset="<?php echo esc_attr( $beauty_logo ); ?><?php echo empty ( $beauty_logo2x ) ? '' : ', ' . esc_url( $beauty_logo2x ) . ' 2x'; ?>" class="img-fluid" <?php echo BeautyHelpers::get_logo_dimensions(); ?> />
							<?php
							else :
							?>
								<h1><?php bloginfo( 'name' ); ?></h1>
							<?php
							endif;
							?>
						</a>
						<?php if ( empty( $beauty_logo ) ) : ?>
						<div class="header__tagline">
							<?php bloginfo( 'description' ); ?>
						</div>
						<?php endif; ?>
					</div>
					<!-- Toggle button for Main Navigation on mobile -->
					<button class="btn  btn-dark  header__navbar-toggler  hidden-lg-up" type="button" data-toggle="collapse" data-target="#beauty-main-navigation"><i class="fa  fa-bars  hamburger"></i> <span><?php esc_html_e( 'MENU' , 'beauty-pt' ); ?></span></button>
					<?php if ( is_active_sidebar( 'navigation-widgets' ) ) : ?>
					<!-- Header navigation widget area -->
					<div class="header__navigation-widgets">
						<?php dynamic_sidebar( apply_filters( 'beauty_navigation_widgets', 'navigation-widgets', get_the_ID() ) ); ?>
					</div>
					<?php endif; ?>
					<!-- Main Navigation -->
					<nav class="header__navigation  collapse  navbar-toggleable-md  js-sticky-offset" id="beauty-main-navigation" aria-label="<?php esc_html_e( 'Main Menu', 'beauty-pt' ); ?>">
						<!-- Home Icon in Navigation -->
						<?php if ( 'yes' === get_theme_mod( 'main_navigation_home_icon', 'yes' ) ) : ?>
						<a class="home-icon" href="<?php echo esc_url( home_url( '/' ) ); ?>">
							<i class="fa  fa-home"></i>
						</a>
						<?php endif;

						if ( has_nav_menu( 'main-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'main-menu',
								'container'      => false,
								'menu_class'     => 'main-navigation  js-main-nav js-dropdown',
								'walker'         => new Aria_Walker_Nav_Menu(),
								'items_wrap'     => '<ul id="%1$s" class="%2$s" role="menubar">%3$s</ul>',
							) );
						}
						?>
					</nav>
					<?php if ( 'center-logo' === get_theme_mod( 'header_layout', 'left-logo' ) ) : ?>
						<!-- Header left widget area -->
						<div class="header__left-widgets">
							<?php
							if ( is_active_sidebar( 'header-left-widgets' ) ) {
								dynamic_sidebar( apply_filters( 'beauty_header_left_widgets', 'header-left-widgets', get_the_ID() ) );
							}
							?>
						</div>
					<?php endif; ?>
					<!-- Header right widget area -->
					<div class="header__right-widgets">
						<?php
						if ( is_active_sidebar( 'header-right-widgets' ) ) {
							dynamic_sidebar( apply_filters( 'beauty_header_right_widgets', 'header-right-widgets', get_the_ID() ) );
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</header>