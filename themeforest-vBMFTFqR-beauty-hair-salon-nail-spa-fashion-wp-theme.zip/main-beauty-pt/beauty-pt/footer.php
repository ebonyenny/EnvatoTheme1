<?php
/**
 * Footer
 *
 * @package Beauty
 */

$beauty_footer_widgets_layout = BeautyHelpers::footer_widgets_layout_array();

$footer_middle_left_txt  = get_theme_mod( 'footer_middle_left_txt', 'In our salon we support credit cards &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <i class="fa  fa-3x  fa-cc-visa"></i> &nbsp; <i class="fa  fa-3x  fa-cc-mastercard"></i> &nbsp; <i class="fa  fa-3x  fa-cc-amex"></i> &nbsp; <i class="fa  fa-3x fa-cc-paypal"></i>' );
$footer_middle_right_txt = get_theme_mod( 'footer_middle_right_txt', 'Find us &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href="https://www.facebook.com/ProteusThemes/"><i class="fa  fa-2x  fa-facebook"></i></a> &nbsp; &nbsp; <a href="https://twitter.com/ProteusThemes"><i class="fa  fa-2x  fa-twitter"></i></a> &nbsp; &nbsp; <a href="https://www.youtube.com/user/ProteusNetCompany"><i class="fa  fa-2x  fa-youtube"></i></a>' );
$footer_back_to_top      = get_theme_mod( 'footer_back_to_top', 'yes' );

?>

	<footer class="footer">
		<?php if ( ! empty( $beauty_footer_widgets_layout ) && is_active_sidebar( 'footer-widgets' ) ) : ?>
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<?php
					if ( is_active_sidebar( 'footer-widgets' ) ) {
						dynamic_sidebar( 'footer-widgets' );
					}
					?>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<?php if ( ! ( 'no' === $footer_back_to_top && empty( $footer_middle_left_txt ) && empty( $footer_middle_right_txt ) ) ) : ?>
		<div class="footer-middle__container">
			<div class="container">
				<div class="footer-middle">
					<div class="footer-middle__left">
					<?php echo wp_kses_post( apply_filters( 'beauty_footer_middle_left_txt', $footer_middle_left_txt ) ); ?>
					</div>
					<?php if ( 'yes' === $footer_back_to_top ) : ?>
						<a href="#" class="footer-middle__back-to-top">
							<?php echo get_theme_mod( 'footer_back_to_top_text', esc_html__( 'Back to top' , 'beauty-pt' ) ); ?>
						</a>
					<?php endif; ?>
					<div class="footer-middle__right">
					<?php echo wp_kses_post( apply_filters( 'beauty_footer_middle_right_txt', $footer_middle_right_txt ) ); ?>
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<div class="footer-bottom">
			<div class="container">
				<?php echo wp_kses_post( apply_filters( 'beauty_footer_bottom_txt', get_theme_mod( 'footer_bottom_txt', '<a href="https://www.proteusthemes.com/wordpress-themes/beauty/">Beauty Theme</a> Made by ProteusThemes. Copyright &copy; 2009–' . date( 'Y' ) . '.' ) ) ); ?>
			</div>
		</div>
	</footer>
	</div><!-- end of .boxed-container -->

	<?php wp_footer(); ?>
	</body>
</html>