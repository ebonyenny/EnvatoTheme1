<?php
/**
 * The template used for displaying page content in page.php
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?>>

	<!-- Solve Microformats error -->
	<span class="hidden-xs-up  entry-title"><?php the_title(); ?></span>
	<span class="hidden-xs-up  vcard  author">
		<span class="fn"><?php the_author(); ?></span>
	</span>
	<time datetime="<?php the_time( 'c' ); ?>" class="hidden-xs-up  published"><?php echo get_the_date(); ?></time>
	<time class="hidden-xs-up  updated"><?php the_modified_date(); ?></time>

	<div class="hentry__content  entry-content">
		<?php the_content(); ?>
		<!-- Multi Page in One Post -->
		<?php
			$beauty_args = array(
				'before'      => '<div class="multi-page  clearfix">' . /* translators: after that comes pagination like 1, 2, 3 ... 10 */ esc_html__( 'Pages:', 'beauty-pt' ) . ' &nbsp; ',
				'after'       => '</div>',
				'link_before' => '<span class="btn  btn-primary">',
				'link_after'  => '</span>',
				'echo'        => 1,
			);
			wp_link_pages( $beauty_args );
		?>
	</div><!-- .entry-content -->
</article><!-- #post-## -->