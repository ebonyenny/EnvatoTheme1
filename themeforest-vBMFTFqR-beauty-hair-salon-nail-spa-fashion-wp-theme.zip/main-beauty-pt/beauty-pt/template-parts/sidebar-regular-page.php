<?php
/**
 * Template part for displaying page sidebar
 */

$beauty_sidebar = get_field( 'sidebar' );

if ( ! $beauty_sidebar ) {
	$beauty_sidebar = 'left';
}

if ( 'none' !== $beauty_sidebar && is_active_sidebar( 'regular-page-sidebar' ) ) : ?>
	<div class="col-xs-12  col-lg-3<?php echo 'left' === $beauty_sidebar ? '  col-lg-pull-9' : ''; ?>">
		<div class="sidebar" role="complementary">
			<?php dynamic_sidebar( apply_filters( 'beauty_regular_page_sidebar', 'regular-page-sidebar', get_the_ID() ) ); ?>
		</div>
	</div>
<?php endif; ?>