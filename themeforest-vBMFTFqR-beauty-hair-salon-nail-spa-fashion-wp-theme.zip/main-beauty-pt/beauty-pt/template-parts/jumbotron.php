<div class="jumbotron  jumbotron--<?php echo 'caption' === get_field( 'slider_content' ) ? 'with-captions' : 'no-caption'; ?>  clearfix">
	<div class="carousel  slide  js-jumbotron-slider" id="headerCarousel" data-ride="carousel" <?php printf( 'data-interval="%s"', get_field( 'auto_cycle' ) ? get_field( 'cycle_interval' ) : 'false' ); ?>>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
		<?php
			$i = -1;
			$beauty_slider_captions = array();
			$beauty_has_captions = 'caption' === get_field( 'slider_content' );

			while ( have_rows( 'slides' ) ) :
				the_row();
				$i++;

				$beauty_slider_sizes = array( 'beauty-jumbotron-slider-l', 'beauty-jumbotron-slider-m', 'beauty-jumbotron-slider-s' );

				$beauty_slide_image_srcset = BeautyHelpers::get_image_srcset( get_sub_field( 'slide_image' ), $beauty_slider_sizes );
				$beauty_slide_link         = get_sub_field( 'slide_link' );

				$beauty_slider_src_img = wp_get_attachment_image_src( absint( get_sub_field( 'slide_image' ) ), 'beauty-jumbotron-slider-s' );

				if ( $beauty_has_captions ) {
					$beauty_slider_captions[] = array(
						'title' => get_sub_field( 'slide_title' ),
						'text'  => get_sub_field( 'slide_text' ),
					);
				}
		?>

			<div class="carousel-item <?php echo 0 === $i ? ' active' : ''; ?>">
				<?php if ( ! empty( $beauty_slide_link ) && 'link' === get_field( 'slider_content' ) ) :?>
					<a href="<?php echo esc_url( $beauty_slide_link ); ?>" target="<?php echo ( get_sub_field( 'slide_open_link_in_new_window' ) ) ?  '_blank' : '_self' ?>">
				<?php endif; ?>
				<img src="<?php echo esc_url( $beauty_slider_src_img[0] ); ?>" srcset="<?php echo esc_attr( $beauty_slide_image_srcset ); ?>" sizes="100vw" alt="<?php echo esc_attr( get_sub_field( 'slide_title' ) ); ?>">
				<?php if ( ! empty( $beauty_slide_link ) && 'link' === get_field( 'slider_content' ) ) :?>
					</a>
				<?php endif; ?>
			</div>

		<?php
			endwhile;
		?>

		</div>

	</div>

	<!-- Controls -->
	<a class="left  jumbotron__control" href="#headerCarousel" role="button" data-slide="prev">
		<i class="fa  fa-angle-left"></i>
	</a>
	<a class="right  jumbotron__control" href="#headerCarousel" role="button" data-slide="next">
		<i class="fa  fa-angle-right"></i>
	</a>

	<!-- Slider Content -->
	<?php if ( ! empty( $beauty_slider_captions ) ) : ?>
	<div class="container">
		<div class="jumbotron-content  js-slider-captions">
			<h1 class="jumbotron-content__title  js-slider-captions__title"><?php echo esc_html( $beauty_slider_captions[0]['title'] ); ?></h1>
			<div class="jumbotron-content__description  js-slider-captions__text">
				<?php echo wp_kses_post( $beauty_slider_captions[0]['text'] ); ?>
			</div>
		</div>
	</div>
	<script>window.BeautySliderCaptions = <?php echo wp_json_encode( $beauty_slider_captions ); ?>;</script>
	<?php endif; ?>

</div>
