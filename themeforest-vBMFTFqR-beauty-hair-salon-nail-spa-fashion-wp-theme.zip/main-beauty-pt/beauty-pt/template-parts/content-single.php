<?php
/**
 * Template part for displaying single posts.
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?>>
	<header class="hentry__header">
		<?php the_title( '<h1 class="hentry__title  entry-title">', '</h1>' ); ?>
		<?php if ( 'post' == get_post_type() ) : ?>
			<div class="hentry__meta  meta">
				<?php get_template_part( 'template-parts/meta' ); ?>
			</div><!-- .hentry__meta -->
		<?php endif; ?>
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'post-thumbnail', array( 'class' => 'img-fluid  hentry__featured-image' ) ); ?>
		<?php endif; ?>
	</header><!-- .entry-header -->

	<div class="hentry__content  entry-content">
		<?php the_content(); ?>

		<!-- Multi Page in One Post -->
		<?php
			$beauty_args = array(
				'before'      => '<div class="multi-page  clearfix">' . /* translators: after that comes pagination like 1, 2, 3 ... 10 */ esc_html__( 'Pages:', 'beauty-pt' ) . ' &nbsp; ',
				'after'       => '</div>',
				'link_before' => '<span class="btn  btn-primary">',
				'link_after'  => '</span>',
				'echo'        => 1,
			);
			wp_link_pages( $beauty_args );
		?>
	</div><!-- .entry-content -->
</article><!-- #post-## -->