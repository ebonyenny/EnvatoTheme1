<?php if ( function_exists( 'bcn_display' ) ) : ?>
	<div class="breadcrumbs">
		<?php bcn_display(); ?>
	</div>
<?php endif; ?>