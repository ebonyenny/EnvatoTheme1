<i class="fa fa-calendar-o"></i> <time datetime="<?php the_time( 'c' ); ?>" class="meta__item  meta__item--date  published"><?php echo get_the_date(); ?></time>
<time class="hidden-xs-up  updated"><?php the_modified_date(); ?></time>
<i class="fa fa-user"></i>
<span class="vcard  author">
	<span class="meta__item  meta__item--author"><span class="fn"><?php the_author(); ?></span></span>
</span>
<?php if ( has_category() ) { ?>
	<i class="fa fa-th-list"></i> <span class="meta__item  meta__item--categories"><?php esc_html_e( '' , 'beauty-pt' ); ?> <?php the_category( ', ' ); ?></span>
<?php } ?>
<?php if ( has_tag() ) { ?>
	<i class="fa fa-tag"></i> <span class="meta__item  meta__item--tags"><?php esc_html_e( '' , 'beauty-pt' ); ?> <?php the_tags( '', ', ' ); ?></span>
<?php } ?>
<?php if ( comments_open( get_the_ID() ) ) : // only show comments count if the comments are open ?>
	<i class="fa fa-comment"></i> <span class="meta__item  meta__item--comments"><a href="<?php comments_link(); ?>"><?php BeautyHelpers::pretty_comments_number(); ?></a></span>
<?php endif; ?>