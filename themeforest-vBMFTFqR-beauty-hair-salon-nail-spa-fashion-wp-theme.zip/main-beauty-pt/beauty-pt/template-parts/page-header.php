<?php

$beauty_blog_id      = absint( get_option( 'page_for_posts' ) );
$beauty_style_attr   = '';
$beauty_shop_id      = absint( get_option( 'woocommerce_shop_page_id', 0 ) );

// custom bg
$beauty_bg_id = get_the_ID();


if ( is_home() || is_singular( 'post' ) ) {
	$beauty_bg_id = $beauty_blog_id;
}

// woocommerce
if ( BeautyHelpers::is_woocommerce_active() && is_woocommerce() ) {
	$beauty_bg_id = $beauty_shop_id;
}

$show_page_header_area = get_field( 'show_page_header_area', $beauty_bg_id );
if ( ! $show_page_header_area ) {
	$show_page_header_area = 'yes';
}

// show/hide page header area (ACF control - single page && customizer control - all pages)
if ( 'yes' === $show_page_header_area && 'yes' === get_theme_mod( 'show_page_header', 'yes' ) ) :

	$beauty_style_array = array();

	if ( get_field( 'background_image', $beauty_bg_id ) ) {
		$beauty_style_array = array(
			'background-image'      => get_field( 'background_image', $beauty_bg_id ),
			'background-position'   => get_field( 'background_image_horizontal_position', $beauty_bg_id ) . ' ' . get_field( 'background_image_vertical_position', $beauty_bg_id ),
			'background-repeat'     => get_field( 'background_image_repeat', $beauty_bg_id ),
			'background-attachment' => get_field( 'background_image_attachment', $beauty_bg_id ),
		);
	}

	$beauty_style_array['background-color'] = get_field( 'background_color', $beauty_bg_id );

	$beauty_style_attr = BeautyHelpers::create_background_style_attr( $beauty_style_array );

	?>

	<div class="page-header__container" style="<?php echo esc_attr( $beauty_style_attr ); ?>">
		<div class="container">
			<div class="page-header">
				<div class="page-header__text">
					<?php
					$beauty_main_tag = 'h1';
					$beauty_subtitle = false;

					if ( is_home() || ( is_single() && 'post' === get_post_type() ) ) {
						$beauty_title    = get_the_title( $beauty_blog_id );
						$beauty_subtitle = get_field( 'subtitle', $beauty_blog_id );

						if ( is_single() ) {
							$beauty_main_tag = 'h2';
						}
					}
					elseif ( BeautyHelpers::is_woocommerce_active() && is_woocommerce() ) {
							ob_start();
							woocommerce_page_title();
							$beauty_title    = ob_get_clean();
							$beauty_subtitle = get_field( 'subtitle', $beauty_shop_id );

							if ( is_product() ) {
								$beauty_main_tag = 'h2';
							}
					}
					elseif ( is_category() || is_tag() || is_author() || is_post_type_archive() || is_tax() || is_day() || is_month() || is_year() ) {
						$beauty_title = get_the_archive_title();
					}
					elseif ( is_search() ) {
						$beauty_title = esc_html__( 'Search Results For' , 'beauty-pt' ) . ' &quot;' . get_search_query() . '&quot;';
					}
					elseif ( is_404() ) {
						$beauty_title = esc_html__( 'Error 404' , 'beauty-pt' );
					}
					else {
						$beauty_title    = get_the_title();
						$beauty_subtitle = get_field( 'subtitle' );
					}

					?>

					<?php printf( '<%1$s class="page-header__title">%2$s</%1$s>', tag_escape( $beauty_main_tag ), esc_html( $beauty_title ) ); ?>

					<?php if ( $beauty_subtitle ) : ?>
						<p class="page-header__subtitle"><?php echo esc_html( $beauty_subtitle ); ?></p>
					<?php endif; ?>
				</div>

				<!-- Breadcrumbs -->
				<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
			</div>
		</div>
	</div>
<?php endif; ?>
