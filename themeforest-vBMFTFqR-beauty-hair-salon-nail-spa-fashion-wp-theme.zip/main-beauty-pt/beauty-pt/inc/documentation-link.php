<?php
/**
 * Add the link to documentation under Appearance in the wp-admin
 */

if ( ! function_exists( 'beauty_add_docs_page' ) ) {
	function beauty_add_docs_page() {
		add_theme_page(
			_x( 'Documentation', 'backend', 'beauty-pt' ),
			_x( 'Documentation', 'backend', 'beauty-pt' ),
			'',
			'proteusthemes-theme-docs',
			'beauty_docs_page_output'
		);
	}
	add_action( 'admin_menu', 'beauty_add_docs_page' );

	function beauty_docs_page_output() {
		?>
		<div class="wrap">
			<h2><?php _ex( 'Documentation', 'backend', 'beauty-pt' ); ?></h2>

			<p>
				<strong><a href="https://www.proteusthemes.com/docs/beauty-pt/" class="button button-primary " target="_blank"><?php _ex( 'Click here to see online documentation of the theme!', 'backend', 'beauty-pt' ); ?></a></strong>
			</p>
		</div>
		<?php
	}
}