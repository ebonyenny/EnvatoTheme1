<?php

use ProteusThemes\CustomizerUtils\Setting;
use ProteusThemes\CustomizerUtils\Control;

/**
 * Contains methods for customizing the theme customization screen.
 *
 * @package Beauty
 * @link http://codex.wordpress.org/Theme_Customization_API
 */

class Beauty_Customizer_Base {
	/**
	 * The singleton manager instance
	 *
	 * @see wp-includes/class-wp-customize-manager.php
	 * @var WP_Customize_Manager
	 */
	protected $wp_customize;

	// Holds the array for the DynamiCSS
	private $dynamic_css = array();

	public function __construct( WP_Customize_Manager $wp_manager ) {
		// init the dynamic_css property
		$this->dynamic_css = $this->dynamic_css_init();

		// set the private propery to instance of wp_manager
		$this->wp_customize = $wp_manager;

		// register the settings/panels/sections/controls, main method
		$this->register();

		/**
		 * Action and filters
		 */

		// render the CSS and cache it to the theme_mod when the setting is saved
		add_action( 'customize_save_after' , array( $this, 'cache_rendered_css' ) );

		// save logo width/height dimensions
		add_action( 'customize_save_logo_img' , array( __CLASS__, 'save_logo_dimensions' ), 10, 1 );

		// handle the postMessage transfer method with some dynamically generated JS in the footer of the theme
		add_action( 'customize_preview_init', array( $this, 'enqueue_customizer_js' ), 31 );
	}

	private function dynamic_css_init () {
		$darken3   = new Setting\DynamicCSS\ModDarken( 3 );
		$darken5   = new Setting\DynamicCSS\ModDarken( 5 );
		$darken7   = new Setting\DynamicCSS\ModDarken( 7 );
		$darken13  = new Setting\DynamicCSS\ModDarken( 13 );
		$darken20  = new Setting\DynamicCSS\ModDarken( 20 );
		$lighten5  = new Setting\DynamicCSS\ModLighten( 5 );
		$lighten7  = new Setting\DynamicCSS\ModLighten( 7 );
		$lighten13 = new Setting\DynamicCSS\ModLighten( 13 );
		$image_url = new Setting\DynamicCSS\ModPrependAppend( 'url(', ')' );

		return array(
			'top_bar_bg' => array(
				'default'    => '#333333',
				'css_props' => array( // list of all css properties this setting controls
					array( // each property in it's own array
						'name'      => 'background-color',
						'selectors' => array(
							'noop' => array( // regular selectors
								'.top',
								'.top-navigation a',
							),
						),
					),
				),
			),

			'top_bar_color' => array(
				'default'    => '#999999',
				'css_props' => array(
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.top',
								'.top-navigation a',
								'.top .icon-box__title',
							),
						),
					),
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.top .icon-box__subtitle',
							),
						),
						'modifier'  => $lighten7,
					),
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.top-navigation a:focus',
								'.top-navigation a:hover',
							),
						),
						'modifier'  => $darken5,
					),
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.top .icon-box .fa',
							),
						),
						'modifier'  => $darken20,
					),
				),
			),

			'header_bg' => array(
				'default'    => '#ffffff',
				'css_props' => array(
					array(
						'name'      => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.header__container',
							),
						),
					),
				),
			),

			'main_navigation_mobile_background' => array(
				'default' => '#eeeeee',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'@media (max-width: 991px)' => array(
								'.home-icon',
								'.main-navigation',
							),
						),
					),
					array(
						'name' => 'border-color',
						'selectors' => array(
							'@media (max-width: 991px)' => array(
								'.home-icon',
								'.main-navigation',
								'.main-navigation a',
								'.main-navigation > .menu-item-has-children + .menu-item',
							),
						),
						'modifier'  => $darken7,
					),
				),
			),

			'main_navigation_mobile_color' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (max-width: 991px)' => array(
								'.home-icon',
								'.main-navigation a',
							),
						),
					),
				),
			),

			'main_navigation_mobile_color_hover' => array(
				'default' => '#000000',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (max-width: 991px)' => array(
								'.home-icon:focus',
								'.home-icon:hover',
								'.main-navigation .menu-item:focus > a',
								'.main-navigation .menu-item:hover > a',
							),
						),
					),
				),
			),

			'main_navigation_mobile_sub_color_background' => array(
				'default' => '#ffffff',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'@media (max-width: 991px)' => array(
								'.main-navigation .sub-menu',
							),
						),
					),
				),
			),

			'main_navigation_mobile_sub_color' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (max-width: 991px)' => array(
								'.main-navigation .sub-menu a',
							),
						),
					),
				),
			),

			'main_navigation_mobile_sub_color_hover' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (max-width: 991px)' => array(
								'.main-navigation .sub-menu .menu-item:focus > a',
								'.main-navigation .sub-menu .menu-item:hover > a',
							),
						),
					),
				),
			),

			'main_navigation_color' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation a',
								'.main-navigation > .menu-item-has-children::after',
							),
						),
					),
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.home-icon',
							),
						),
						'modifier'  => $lighten13,
					),
				),
			),

			'main_navigation_color_hover' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.home-icon:focus',
								'.home-icon:hover',
								'.main-navigation .menu-item:focus > a',
								'.main-navigation .menu-item:hover > a',
								'.main-navigation > .current-menu-item > a',
								'.main-navigation > .menu-item-has-children:focus::after',
								'.main-navigation > .menu-item-has-children:hover::after',
								'.main-navigation > .menu-item-has-children.current-menu-item::after',
							),
						),
					),
					array(
						'name' => 'background-color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation > .current-menu-item > a::after',
							),
						),
					),
				),
			),

			'main_navigation_sub_bg' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation .sub-menu a',
							),
						),
					),
					array(
						'name' => 'background-color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation .sub-menu .menu-item:focus > a',
								'.main-navigation .sub-menu .menu-item:hover > a',
							),
						),
						'modifier'  => $lighten7,
					),
					array(
						'name' => 'border-color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation .sub-menu a',
								'.main-navigation .sub-menu .sub-menu a',
							),
						),
						'modifier'  => $lighten7,
					),
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation .sub-menu .menu-item-has-children::after',
							),
						),
						'modifier'  => $lighten7,
					),
				),
			),

			'main_navigation_sub_color' => array(
				'default' => '#999999',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation .sub-menu a',
							),
						),
					),
				),
			),

			'main_navigation_sub_color_hover' => array(
				'default' => '#ffffff',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'@media (min-width: 992px)' => array(
								'.main-navigation .sub-menu .menu-item:focus > a',
								'.main-navigation .sub-menu .menu-item:hover > a',
							),
						),
					),
				),
			),

			'page_header_bg_color' => array(
				'default' => '#f2f2f2',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.page-header__container',
							),
						),
					),
					array(
						'name' => 'border-color',
						'selectors' => array(
							'noop' => array(
								'.page-header__container',
							),
						),
						'modifier'  => $darken3,
					),
				),
			),

			'page_header_bg_img' => array(
				'css_props' => array(
					array(
						'name' => 'background-image',
						'selectors' => array(
							'noop' => array(
								'.page-header__container',
							),
						),
						'modifier' => $image_url,
					),
				),
			),

			'page_header_color' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.page-header h1',
								'.page-header h2',
							),
						),
					),
				),
			),

			'page_header_subtitle_color' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.page-header__subtitle',
							),
						),
					),
				),
			),

			'breadcrumbs_color' => array(
				'default'    => '#aaaaaa',
				'css_props' => array(
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.breadcrumbs',
								'.breadcrumbs a',
								'.breadcrumbs a::after',
							),
						),
					),
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.breadcrumbs a:focus',
								'.breadcrumbs a:hover',
							),
						),
						'modifier'  => $darken13,
					),
				),
			),

			'breadcrumbs_color_active' => array(
				'default'    => '#aaaaaa',
				'css_props' => array(
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.breadcrumbs span > span',
								'.breadcrumbs .current-item',
							),
						),
					),
					array(
						'name'      => 'color',
						'selectors' => array(
							'noop' => array(
								'.breadcrumbs .current-item:focus',
								'.breadcrumbs .current-item:hover',
							),
						),
						'modifier'  => $darken13,
					),
				),
			),

			'text_color_content_area' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.content-area',
								'.icon-box__subtitle',
							),
						),
					),
				),
			),

			'headings_color' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'h1',
								'h2',
								'h3',
								'h4',
								'h5',
								'h6',
								'hentry__title',
								'.hentry__title a',
								'.page-box__title a',
								'.accordion__panel .panel-title a',
								'body.woocommerce-page ul.products li.product h3',
								'.woocommerce ul.products li.product h3',
							),
						),
					),
				),
			),

			'primary_color' => array(
				'default' => '#7f6aa5',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.icon-box .fa',
								'.person-profile__social-icon:focus',
								'.person-profile__social-icon:hover',
								'.footer-top a.icon-container:hover',
								'.footer-middle__back-to-top',
								'body.woocommerce-page ul.products li.product a',
								'body.woocommerce-page ul.products li.product a:hover img',
								'.woocommerce ul.products li.product a',
								'.woocommerce ul.products li.product a:hover img',
								'body.woocommerce-page ul.products li.product .price',
								'.woocommerce ul.products li.product .price',
								'body.woocommerce-page .star-rating',
								'.woocommerce .star-rating',
								'body.woocommerce-page div.product p.price',
								'body.woocommerce-page p.stars a',
								'body.woocommerce-page ul.product_list_widget .amount',
								'.woocommerce.widget_shopping_cart .total .amount',
							),
						),
					),
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.person-profile__tag',
								'.widget_calendar caption',
								'.pricing-list__badge',
								'.btn-primary',
								'body.woocommerce-page .woocommerce-error a.button',
								'body.woocommerce-page .woocommerce-info a.button',
								'body.woocommerce-page .woocommerce-message a.button',
								'.woocommerce-cart .wc-proceed-to-checkout a.checkout-button',
								'body.woocommerce-page #payment #place_order',
								'body.woocommerce-page #review_form #respond input#submit',
								'body.woocommerce-page .widget_product_search .search-field + input',
								'body.woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle',
								'body.woocommerce-page .widget_price_filter .ui-slider .ui-slider-range',
							),
						),
					),
					array(
						'name' => 'border-color',
						'selectors' => array(
							'noop' => array(
								'.logo-panel img:hover',
								'.btn-primary',
							),
						),
					),
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.footer-middle__back-to-top:focus',
								'.footer-middle__back-to-top:hover',
							),
						),
						'modifier'  => $darken7,
					),
					array(
						'name' => 'border-color',
						'selectors' => array(
							'noop' => array(
								'.btn-primary:focus',
								'.btn-primary:active',
								'.btn-primary:hover',
								'.btn-primary:active:hover',
								'.btn-primary:active:focus',
							),
						),
						'modifier'  => $darken7,
					),
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.btn-primary:focus',
								'.btn-primary:active',
								'.btn-primary:hover',
								'.btn-primary:active:hover',
								'.btn-primary:active:focus',
								'body.woocommerce-page .widget_product_search .search-field + input:hover',
								'body.woocommerce-page .widget_product_search .search-field + input:focus',
								'body.woocommerce-page .woocommerce-error a.button:hover',
								'body.woocommerce-page .woocommerce-info a.button:hover',
								'body.woocommerce-page .woocommerce-message a.button:hover',
								'.woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover',
								'body.woocommerce-page #payment #place_order:hover',
							),
						),
						'modifier'  => $darken7,
					),
				),
			),

			'link_color' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'a',
							),
						),
					),
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'a:focus',
								'a:hover',
							),
						),
						'modifier'  => $darken7,
					),
				),
			),

			'dark_button_color' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.btn-dark',
							),
						),
					),
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.btn-dark:focus',
								'.btn-dark:hover',
							),
						),
						'modifier' => $darken5,
					),
				),
			),

			'light_button_color' => array(
				'default' => '#eeeeee',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.btn-light',
							),
						),
					),
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.btn-light:focus',
								'.btn-light:hover',
							),
						),
						'modifier' => $darken5,
					),
				),
			),

			'footer_bg_color' => array(
				'default' => '#333333',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.footer-top',
								'.footer-middle__container',
							),
						),
					),
				),
			),

			'footer_title_color' => array(
				'default' => '#eeeeee',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.footer-top__headings'
							),
						),
					),
				),
			),

			'footer_text_color' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.footer-top',
							),
						),
					),
				),
			),

			'footer_link_color' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.footer-top .widget_nav_menu .menu a',
							),
						),
					),
				),
			),

			'footer_middle_text_color' => array(
				'default' => '#eeeeee',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.footer-middle',
							),
						),
					),
				),
			),

			'footer_bottom_bg_color' => array(
				'default' => '#222222',
				'css_props' => array(
					array(
						'name' => 'background-color',
						'selectors' => array(
							'noop' => array(
								'.footer-bottom',
							),
						),
					),
				),
			),

			'footer_bottom_text_color' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.footer-bottom',
							),
						),
					),
				),
			),

			'footer_bottom_link_color' => array(
				'default' => '#aaaaaa',
				'css_props' => array(
					array(
						'name' => 'color',
						'selectors' => array(
							'noop' => array(
								'.footer-bottom a',
							),
						),
					),
				),
			),

		);
	}

	/**
	* This hooks into 'customize_register' (available as of WP 3.4) and allows
	* you to add new sections and controls to the Theme Customize screen.
	*
	* Note: To enable instant preview, we have to actually write a bit of custom
	* javascript. See live_preview() for more.
	*
	* @see add_action('customize_register',$func)
	*/
	public function register () {
		/**
		 * Settings
		 */

		// branding
		$this->wp_customize->add_setting( 'logo_img' );
		$this->wp_customize->add_setting( 'logo2x_img' );
		$this->wp_customize->add_setting( 'logo_top_margin', array( 'default' => 32 ) );

		// header
		$this->wp_customize->add_setting( 'top_bar_visibility', array( 'default' => 'yes' ) );
		$this->wp_customize->add_setting( 'header_layout', array( 'default' => 'left-logo' ) );

		// navigation
		$this->wp_customize->add_setting( 'main_navigation_home_icon', array( 'default' => 'yes' ) );
		$this->wp_customize->add_setting( 'main_navigation_sticky', array( 'default' => 'static' ) );

		// page header area
		$this->wp_customize->add_setting( 'show_page_header', array( 'default' => 'yes' ) );

		// typography
		$this->wp_customize->add_setting( 'charset_setting', array( 'default' => 'latin' ) );

		// theme layout & color
		$this->wp_customize->add_setting( 'layout_mode', array( 'default' => 'wide' ) );

		// shop
		if ( BeautyHelpers::is_woocommerce_active() ) {
			$this->wp_customize->add_setting( 'products_per_page', array( 'default' => 9 ) );
			$this->wp_customize->add_setting( 'single_product_sidebar', array( 'default' => 'left' ) );
		}

		// footer
		$this->wp_customize->add_setting( 'footer_widgets_layout', array( 'default' => '[4,6,8]' ) );

		$this->wp_customize->add_setting( 'footer_bottom_txt', array( 'default' => '<a href="https://www.proteusthemes.com/wordpress-themes/beauty/">Beauty Theme</a> Made by ProteusThemes. Copyright &copy; 2009–' . date( 'Y' ) . '.' ) );

		$this->wp_customize->add_setting( 'footer_middle_left_txt', array( 'default' => 'In our salon we support credit cards &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <i class="fa  fa-3x  fa-cc-visa"></i> &nbsp; <i class="fa  fa-3x  fa-cc-mastercard"></i> &nbsp; <i class="fa  fa-3x  fa-cc-amex"></i> &nbsp; <i class="fa  fa-3x fa-cc-paypal"></i>' ) );

		$this->wp_customize->add_setting( 'footer_middle_right_txt', array( 'default' => 'Find us &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href="https://www.facebook.com/ProteusThemes/"><i class="fa  fa-2x  fa-facebook"></i></a> &nbsp; &nbsp; <a href="https://twitter.com/ProteusThemes"><i class="fa  fa-2x  fa-twitter"></i></a> &nbsp; &nbsp; <a href="https://www.youtube.com/user/ProteusNetCompany"><i class="fa  fa-2x  fa-youtube"></i></a>' ) );

		$this->wp_customize->add_setting( 'footer_back_to_top', array( 'default' => 'yes' ) );
		$this->wp_customize->add_setting( 'footer_back_to_top_text', array( 'default' => esc_html__( 'Back to top' , 'beauty-pt' ) ) );

		// custom code (css/js)
		$this->wp_customize->add_setting( 'custom_js_head' );
		$this->wp_customize->add_setting( 'custom_js_footer' );
		$this->wp_customize->add_setting( 'custom_css', array( 'default' => '' ) );

		// Migrate any existing theme CSS to the core option added in WordPress 4.7.
		if ( function_exists( 'wp_update_custom_css_post' ) ) {
			$css = get_theme_mod( 'custom_css', '' );

			if ( ! empty( $css ) ) {
				$core_css = wp_get_custom_css(); // Preserve any CSS already added to the core option.
				$return   = wp_update_custom_css_post( '/* Migrated CSS from old Theme Custom CSS setting: */' . PHP_EOL . $css . PHP_EOL . PHP_EOL . '/* New custom CSS: */' . PHP_EOL . $core_css );
				if ( ! is_wp_error( $return ) ) {
					// Remove the old theme_mod, so that the CSS is stored in only one place moving forward.
					remove_theme_mod( 'custom_css' );
				}
			}

			// Add new "CSS setting" that will only notify the users that the new "Additional CSS" field is available.
			// It can't be the same name ('custom_css'), because the core control is also named 'custom_css' and it would not display the WP core "Additional CSS" control.
			$this->wp_customize->add_setting( 'pt_custom_css', array( 'default' => '' ) );
		}

		// acf
		$this->wp_customize->add_setting( 'show_acf', array( 'default' => 'no' ) );
		$this->wp_customize->add_setting( 'use_minified_css', array( 'default' => 'no' ) );

		// all the DynamicCSS settings
		foreach ( $this->dynamic_css as $setting_id => $args ) {
			$this->wp_customize->add_setting(
				new Setting\DynamicCSS( $this->wp_customize, $setting_id, $args )
			);
		}

		/**
		 * Panel and Sections
		 */

		// one ProteusThemes panel to rule them all
		$this->wp_customize->add_panel( 'panel_beauty', array(
			'title'       => _x( '[PT] Theme Options', 'backend', 'beauty-pt' ),
			'description' => _x( 'All Beauty theme specific settings.', 'backend', 'beauty-pt' ),
			'priority'    => 10,
		) );

		// individual sections
		$this->wp_customize->add_section( 'beauty_section_logos', array(
			'title'       => _x( 'Logo', 'backend', 'beauty-pt' ),
			'description' => _x( 'Logo for the Beauty theme.', 'backend', 'beauty-pt' ),
			'priority'    => 10,
			'panel'       => 'panel_beauty',
		) );

		// Header
		$this->wp_customize->add_section( 'beauty_section_header', array(
			'title'       => _x( 'Header', 'backend', 'beauty-pt' ),
			'description' => _x( 'All layout and appearance settings for the header.', 'backend', 'beauty-pt' ),
			'priority'    => 20,
			'panel'       => 'panel_beauty',
		) );

		$this->wp_customize->add_section( 'beauty_section_navigation', array(
			'title'       => _x( 'Navigation', 'backend', 'beauty-pt' ),
			'description' => _x( 'Navigation for the Beauty theme.', 'backend', 'beauty-pt' ),
			'priority'    => 30,
			'panel'       => 'panel_beauty',
		) );

		$this->wp_customize->add_section( 'beauty_section_page_header', array(
			'title'       => _x( 'Page Header Area', 'backend', 'beauty-pt' ),
			'description' => _x( 'All layout and appearance settings for the page header area (regular pages).', 'backend', 'beauty-pt' ),
			'priority'    => 33,
			'panel'       => 'panel_beauty',
		) );

		$this->wp_customize->add_section( 'beauty_section_theme_colors', array(
			'title'       => _x( 'Theme Layout &amp; Colors', 'backend', 'beauty-pt' ),
			'priority'    => 40,
			'panel'       => 'panel_beauty',
		) );

		if ( BeautyHelpers::is_woocommerce_active() ) {
			$this->wp_customize->add_section( 'beauty_section_shop', array(
				'title'       => _x( 'Shop', 'backend', 'beauty-pt' ),
				'priority'    => 80,
				'panel'       => 'panel_beauty',
			) );
		}

		$this->wp_customize->add_section( 'section_footer', array(
			'title'       => _x( 'Footer', 'backend', 'beauty-pt' ),
			'description' => _x( 'All layout and appearance settings for the footer.', 'backend', 'beauty-pt' ),
			'priority'    => 90,
			'panel'       => 'panel_beauty',
		) );

		$this->wp_customize->add_section( 'section_custom_code', array(
			'title'       => _x( 'Custom Code' , 'backend', 'beauty-pt' ),
			'priority'    => 100,
			'panel'       => 'panel_beauty',
		) );

		$this->wp_customize->add_section( 'section_other', array(
			'title'       => _x( 'Other' , 'backend', 'beauty-pt' ),
			'priority'    => 150,
			'panel'       => 'panel_beauty',
		) );

		/**
		 * Controls
		 */

		// Section: beauty_section_logos
		$this->wp_customize->add_control( new WP_Customize_Image_Control(
			$this->wp_customize,
			'logo_img',
			array(
				'label'       => _x( 'Logo Image', 'backend', 'beauty-pt' ),
				'description' => _x( 'Max height for the logo image is 120px.', 'backend', 'beauty-pt' ),
				'section'     => 'beauty_section_logos',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Image_Control(
			$this->wp_customize,
			'logo2x_img',
			array(
				'label'       => _x( 'Retina Logo Image', 'backend', 'beauty-pt' ),
				'description' => _x( '2x logo size, for screens with high DPI.', 'backend', 'beauty-pt' ),
				'section'     => 'beauty_section_logos',
			)
		) );
		$this->wp_customize->add_control(
			'logo_top_margin',
			array(
				'type'        => 'number',
				'label'       => _x( 'Logo top margin', 'backend', 'beauty-pt' ),
				'description' => _x( 'In pixels.', 'backend', 'beauty-pt' ),
				'section'     => 'beauty_section_logos',
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 120,
					'step' => 5,
				),
			)
		);

		// Section: header
		$this->wp_customize->add_control( 'top_bar_visibility', array(
			'type'        => 'select',
			'priority'    => 0,
			'label'       => _x( 'Top bar visibility', 'backend', 'beauty-pt' ),
			'description' => _x( 'Show or hide?', 'backend', 'beauty-pt' ),
			'section'     => 'beauty_section_header',
			'choices'     => array(
				'yes'         => _x( 'Show', 'backend', 'beauty-pt' ),
				'no'          => _x( 'Hide', 'backend', 'beauty-pt' ),
				'hide_mobile' => _x( 'Hide on Mobile', 'backend', 'beauty-pt' ),
			),
		) );
		$this->wp_customize->add_control( 'header_layout', array(
			'type'        => 'select',
			'priority'    => 1,
			'label'       => _x( 'Header layout', 'backend', 'beauty-pt' ),
			'description' => _x( 'Choose the position of the logo.', 'backend', 'beauty-pt' ),
			'section'     => 'beauty_section_header',
			'choices'     => array(
				'left-logo'   => _x( 'Logo on the left', 'backend', 'beauty-pt' ),
				'center-logo' => _x( 'Logo in the center', 'backend', 'beauty-pt' ),
			),
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'top_bar_bg',
			array(
				'priority' => 2,
				'label'    => _x( 'Top bar background color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_header',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'top_bar_color',
			array(
				'priority' => 3,
				'label'    => _x( 'Top bar text color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_header',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'header_bg',
			array(
				'priority' => 30,
				'label'    => _x( 'Header background color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_header',
			)
		) );

		// Section: beauty_section_navigation
		$this->wp_customize->add_control( 'main_navigation_home_icon', array(
			'type'        => 'select',
			'priority'    => 110,
			'label'       => _x( 'Home Icon', 'backend', 'beauty-pt' ),
			'section'     => 'beauty_section_navigation',
			'choices'     => array(
				'yes'         => _x( 'Show', 'backend', 'beauty-pt' ),
				'no'          => _x( 'Hide', 'backend', 'beauty-pt' ),
			),
		) );
		$this->wp_customize->add_control( 'main_navigation_sticky', array(
			'type'        => 'select',
			'priority'    => 115,
			'label'       => _x( 'Static or sticky navbar?', 'backend', 'beauty-pt' ),
			'section'     => 'beauty_section_navigation',
			'choices'     => array(
				'static' => _x( 'Static', 'backend', 'beauty-pt' ),
				'sticky' => _x( 'Sticky', 'backend', 'beauty-pt' ),
			),
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_color',
			array(
				'priority' => 130,
				'label'    => _x( 'Main navigation link color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_color_hover',
			array(
				'priority' => 132,
				'label'    => _x( 'Main navigation link hover color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_sub_bg',
			array(
				'priority' => 160,
				'label'    => _x( 'Main navigation submenu background', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_sub_color',
			array(
				'priority' => 170,
				'label'    => _x( 'Main navigation submenu link color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_sub_color_hover',
			array(
				'priority' => 175,
				'label'    => _x( 'Main navigation submenu link hover color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_mobile_color',
			array(
				'priority' => 190,
				'label'    => _x( 'Main navigation link color (mobile)', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_mobile_color_hover',
			array(
				'priority' => 192,
				'label'    => _x( 'Main navigation link hover color (mobile)', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_mobile_sub_color_background',
			array(
				'priority' => 193,
				'label'    => _x( 'Main navigation submenu background color (mobile)', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_mobile_sub_color',
			array(
				'priority' => 194,
				'label'    => _x( 'Main navigation submenu link color (mobile)', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_mobile_sub_color_hover',
			array(
				'priority' => 195,
				'label'    => _x( 'Main navigation submenu link hover color (mobile)', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'main_navigation_mobile_background',
			array(
				'priority' => 188,
				'label'    => _x( 'Main navigation background color (mobile)', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_navigation',
			)
		) );

		// section: beauty_section_page_header
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'page_header_bg_color',
			array(
				'priority' => 10,
				'label'    => _x( 'Page Header background color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_page_header',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Image_Control(
			$this->wp_customize,
			'page_header_bg_img',
			array(
				'priority' => 20,
				'label'    => _x( 'Page Header background pattern', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_page_header',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'page_header_color',
			array(
				'priority' => 30,
				'label'    => _x( 'Page Header title color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_page_header',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'page_header_subtitle_color',
			array(
				'priority' => 31,
				'label'    => _x( 'Page Header subtitle color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_page_header',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'breadcrumbs_color',
			array(
				'priority' => 45,
				'label'    => _x( 'Breadcrumbs text color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_page_header',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'breadcrumbs_color_active',
			array(
				'priority' => 50,
				'label'    => _x( 'Breadcrumbs active text color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_page_header',
			)
		) );
		$this->wp_customize->add_control( 'show_page_header', array(
			'type'        => 'select',
			'priority'    => 55,
			'label'       => _x( 'Show page header area', 'backend', 'beauty-pt' ),
			'description' => _x( 'This will hide the header area (title and breadcrumbs) on all pages. You can also hide individual page headers in page settings.', 'backend', 'beauty-pt' ),
			'section'     => 'beauty_section_page_header',
			'choices'     => array(
				'yes'         => _x( 'Show', 'backend', 'beauty-pt' ),
				'no'          => _x( 'Hide', 'backend', 'beauty-pt' ),
			),
		) );

		// Section: beauty_section_theme_colors
		$this->wp_customize->add_control( 'layout_mode', array(
			'type'     => 'select',
			'priority' => 10,
			'label'    => _x( 'Layout', 'backend', 'beauty-pt' ),
			'section'  => 'beauty_section_theme_colors',
			'choices'  => array(
				'wide'  => _x( 'Wide', 'backend', 'beauty-pt' ),
				'boxed' => _x( 'Boxed', 'backend', 'beauty-pt' ),
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'text_color_content_area',
			array(
				'priority' => 30,
				'label'    => _x( 'Text color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_theme_colors',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'link_color',
			array(
				'priority' => 35,
				'label'    => _x( 'Link color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_theme_colors',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'headings_color',
			array(
				'priority' => 33,
				'label'    => _x( 'Headings color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_theme_colors',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'primary_color',
			array(
				'priority' => 34,
				'label'    => _x( 'Primary color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_theme_colors',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'dark_button_color',
			array(
				'priority' => 36,
				'label'    => _x( 'Dark button background color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_theme_colors',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'light_button_color',
			array(
				'priority' => 37,
				'label'    => _x( 'Light button background color', 'backend', 'beauty-pt' ),
				'section'  => 'beauty_section_theme_colors',
			)
		) );

		// Section: beauty_section_shop
		if ( BeautyHelpers::is_woocommerce_active() ) {
			$this->wp_customize->add_control( 'products_per_page', array(
					'label'   => _x( 'Number of products per page', 'backend', 'beauty-pt' ),
					'section' => 'beauty_section_shop',
				)
			);
			$this->wp_customize->add_control( 'single_product_sidebar', array(
					'label'   => _x( 'Sidebar on single product page', 'backend', 'beauty-pt' ),
					'section' => 'beauty_section_shop',
					'type'    => 'select',
					'choices' => array(
						'none'  => _x( 'No sidebar', 'backend', 'beauty-pt' ),
						'left'  => _x( 'Left', 'backend', 'beauty-pt' ),
						'right' => _x( 'Right', 'backend', 'beauty-pt' ),
					)
				)
			);
		}

		// Section: section_footer
		$this->wp_customize->add_control( new Control\LayoutBuilder(
			$this->wp_customize,
			'footer_widgets_layout',
			array(
				'priority'    => 1,
				'label'       => _x( 'Footer widgets layout', 'backend', 'beauty-pt' ),
				'description' => _x( 'Select number of widget you want in the footer and then with the slider rearrange the layout', 'backend', 'beauty-pt' ),
				'section'     => 'section_footer',
				'input_attrs' => array(
					'min'     => 0,
					'max'     => 12,
					'step'    => 1,
					'maxCols' => 6,
				)
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_bg_color',
			array(
				'priority' => 10,
				'label'    => _x( 'Footer background color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );
		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_title_color',
			array(
				'priority' => 30,
				'label'    => _x( 'Footer widget title color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_text_color',
			array(
				'priority' => 31,
				'label'    => _x( 'Footer text color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_link_color',
			array(
				'priority' => 32,
				'label'    => _x( 'Footer link color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_middle_text_color',
			array(
				'priority' => 33,
				'label'    => _x( 'Footer middle text color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_bottom_bg_color',
			array(
				'priority' => 35,
				'label'    => _x( 'Footer bottom background color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_bottom_text_color',
			array(
				'priority' => 36,
				'label'    => _x( 'Footer bottom text color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );

		$this->wp_customize->add_control( new WP_Customize_Color_Control(
			$this->wp_customize,
			'footer_bottom_link_color',
			array(
				'priority' => 37,
				'label'    => _x( 'Footer bottom link color', 'backend', 'beauty-pt' ),
				'section'  => 'section_footer',
			)
		) );

		$this->wp_customize->add_control( 'footer_back_to_top', array(
			'type'        => 'select',
			'priority'    => 90,
			'label'       => _x( 'Show "Back to top" button?', 'backend', 'beauty-pt' ),
			'section'     => 'section_footer',
			'choices'     => array(
				'yes' => _x( 'Yes', 'backend', 'beauty-pt' ),
				'no'  => _x( 'No', 'backend', 'beauty-pt' ),
			),
		) );

		$this->wp_customize->add_control( 'footer_back_to_top_text', array(
			'type'        => 'text',
			'priority'    => 95,
			'label'       => _x( '"Back to top" button text', 'backend', 'beauty-pt' ),
			'section'     => 'section_footer',
		) );

		$this->wp_customize->add_control( 'footer_middle_left_txt', array(
			'type'        => 'text',
			'priority'    => 100,
			'label'       => _x( 'Footer middle text on the left', 'backend', 'beauty-pt' ),
			'description' => _x( 'You can use HTML: a, span, i, em, strong, img.', 'backend', 'beauty-pt' ),
			'section'     => 'section_footer',
		) );

		$this->wp_customize->add_control( 'footer_middle_right_txt', array(
			'type'        => 'text',
			'priority'    => 105,
			'label'       => _x( 'Footer middle text on the right', 'backend', 'beauty-pt' ),
			'description' => _x( 'You can use HTML: a, span, i, em, strong, img.', 'backend', 'beauty-pt' ),
			'section'     => 'section_footer',
		) );

		$this->wp_customize->add_control( 'footer_bottom_txt', array(
			'type'        => 'text',
			'priority'    => 110,
			'label'       => _x( 'Footer bottom text on the center', 'backend', 'beauty-pt' ),
			'description' => _x( 'You can use HTML: a, span, i, em, strong, img.', 'backend', 'beauty-pt' ),
			'section'     => 'section_footer',
		) );

		// Section: section_custom_code
		if ( function_exists( 'wp_update_custom_css_post' ) ) {
			// Show the notice of custom CSS setting migration.
			$this->wp_customize->add_control( 'pt_custom_css', array(
				'type'        => 'hidden',
				'label'       => esc_html__( 'Custom CSS', 'beauty-pt' ),
				'description' => esc_html__( 'This field is obsolete. The existing code was migrated to the "Additional CSS" field, that can be found in the root of the customizer. This new "Additional CSS" field is a WordPress core field and was introduced in WP version 4.7.', 'beauty-pt' ),
				'section'     => 'section_custom_code',
			) );
		}
		else {
			$this->wp_customize->add_control( 'custom_css', array(
				'type'        => 'textarea',
				'label'       => _x( 'Custom CSS', 'backend', 'beauty-pt' ),
				'description' => sprintf( _x( '%s How to find CSS classes %s in the theme.', 'backend', 'beauty-pt' ), '<a href="https://www.youtube.com/watch?v=V2aAEzlvyDc" target="_blank">', '</a>' ),
				'section'     => 'section_custom_code',
			) );
		}

		$this->wp_customize->add_control( 'custom_js_head', array(
			'type'        => 'textarea',
			'label'       => _x( 'Custom JavaScript (head)', 'backend', 'beauty-pt' ),
			'description' => _x( 'You have to include the &lt;script&gt;&lt;/script&gt; tags as well. Paste your Google Analytics tracking code here.', 'backend', 'beauty-pt' ),
			'section'     => 'section_custom_code',
		) );

		$this->wp_customize->add_control( 'custom_js_footer', array(
			'type'        => 'textarea',
			'label'       => _x( 'Custom JavaScript (footer)', 'backend', 'beauty-pt' ),
			'description' => _x( 'You have to include the &lt;script&gt;&lt;/script&gt; tags as well.', 'backend', 'beauty-pt' ),
			'section'     => 'section_custom_code',
		) );

		// Section: section_other
		$this->wp_customize->add_control( 'show_acf', array(
			'type'        => 'select',
			'label'       => _x( 'Show ACF admin panel?', 'backend', 'beauty-pt' ),
			'description' => _x( 'If you want to use ACF and need the ACF admin panel set this to <strong>Yes</strong>. Do not change if you do not know what you are doing.', 'backend', 'beauty-pt' ),
			'section'     => 'section_other',
			'choices'     => array(
				'no'  => _x( 'No', 'backend', 'beauty-pt' ),
				'yes' => _x( 'Yes', 'backend', 'beauty-pt' ),
			),
		) );
		$this->wp_customize->add_control( 'use_minified_css', array(
			'type'    => 'select',
			'label'   => _x( 'Use minified theme CSS', 'backend', 'beauty-pt' ),
			'section' => 'section_other',
			'choices' => array(
				'no'  => _x( 'No', 'backend', 'beauty-pt' ),
				'yes' => _x( 'Yes', 'backend', 'beauty-pt' ),
			),
		) );
		$this->wp_customize->add_control( 'charset_setting', array(
			'type'     => 'select',
			'label'    => _x( 'Character set for Google Fonts', 'backend' , 'beauty-pt' ),
			'section'  => 'section_other',
			'choices'  => array(
				'latin'        => 'Latin',
				'latin-ext'    => 'Latin Extended',
				'cyrillic'     => 'Cyrillic',
				'cyrillic-ext' => 'Cyrillic Extended',
				'vietnamese'   => 'Vietnamese',
				'greek'        => 'Greek',
				'greek-ext'    => 'Greek Extended',
			)
		) );
	}

	/**
	 * Cache the rendered CSS after the settings are saved in the DB.
	 * This is purely a performance improvement.
	 *
	 * Used by hook: add_action( 'customize_save_after' , array( $this, 'cache_rendered_css' ) );
	 *
	 * @return void
	 */
	public function cache_rendered_css() {
		set_theme_mod( 'cached_css', $this->render_css() );
	}

	/**
	 * Get the dimensions of the logo image when the setting is saved
	 * This is purely a performance improvement.
	 *
	 * Used by hook: add_action( 'customize_save_logo_img' , array( $this, 'save_logo_dimensions' ), 10, 1 );
	 *
	 * @return void
	 */
	public static function save_logo_dimensions( $setting ) {
		$logo_width_height = array();
		$img_data          = getimagesize( esc_url( $setting->post_value() ) );

		if ( is_array( $img_data ) ) {
			$logo_width_height = array_slice( $img_data, 0, 2 );
			$logo_width_height = array_combine( array( 'width', 'height' ), $logo_width_height );
		}

		set_theme_mod( 'logo_dimensions_array', $logo_width_height );
	}

	/**
	 * Render the CSS from all the settings which are of type `Setting\DynamicCSS`
	 *
	 * @return string text/css
	 */
	public function render_css() {
		$out = '';

		foreach ( $this->get_dynamic_css_settings() as $setting ) {
			$out .= $setting->render_css();
		}

		return $out;
	}

	/**
	 * Get only the CSS settings of type `Setting\DynamicCSS`.
	 *
	 * @see is_dynamic_css_setting
	 * @return array
	 */
	public function get_dynamic_css_settings() {
		return array_filter( $this->wp_customize->settings(), array( $this, 'is_dynamic_css_setting' ) );
	}

	/**
	 * Helper conditional function for filtering the settings.
	 *
	 * @see
	 * @param  mixed  $setting
	 * @return boolean
	 */
	protected function is_dynamic_css_setting( $setting ) {
		return is_a( $setting, '\ProteusThemes\CustomizerUtils\Setting\DynamicCSS' );
	}

	/**
	 * Enqueue the JS for live preview the settings of type `Setting\DynamicCSS`.
	 *
	 * All the color changes are transported to the live preview frame using the 'postMessage'
	 * method. The settings key IDs, selectors and CSS props are passed to the script.
	 *
	 * Used by hook: 'customize_preview_init'
	 *
	 * @see add_action('customize_preview_init',$func)
	 */
	public function enqueue_customizer_js() {
		wp_enqueue_script(
			'beauty-live-customize',
			get_template_directory_uri() . '/vendor/proteusthemes/wp-customizer-utilities/assets/live-customize.js',
			array( 'jquery', 'customize-preview' ),
			false,
			true
		);

		wp_localize_script( 'beauty-live-customize', 'ptCustomizerDynamicCSS', $this->js_dynamic_css() );
	}

	/**
	 * Prepare suitable data to pass to JS - only selectors, setting IDs and name of
	 * CSS properties. All selectors are returned, not taking MQ in account.
	 * @return array
	 */
	private function js_dynamic_css() {
		$out = array();

		foreach ( $this->dynamic_css as $setting_id => $setting ) {
			foreach ( $setting['css_props'] as $css_prop ) {
				$css_selectors = array();

				foreach ( $css_prop['selectors'] as $selectors ) {
					$css_selectors += $selectors;
				}

				$css_selectors = array_filter( $css_selectors );
				$css_selectors = array_unique( $css_selectors );

				if ( ! empty( $css_selectors ) ) {
					$out[] = array(
						'settingID' => $setting_id,
						'selectors' => join( ', ', $css_selectors ),
						'cssProp'   => $css_prop['name'],
					);
				}
			}
		}

		return $out;
	}
}
