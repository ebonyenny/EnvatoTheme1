<?php echo $args['before_widget']; ?>

	<div class="time-table">

		<?php
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title'];
		}
		?>

		<div class="inner-bg">
			<?php foreach ( $opening_times as $line ) : ?>
				<dl class="week-day <?php echo esc_html( $line['class'] ); ?>">
					<dt><?php echo esc_html( BeautyHelpers::substr( $line['day'], 0, 3 ) ); ?></dt>
					<dd><?php echo esc_html( $line['day-time'] ); ?></dd>
				</dl>
			<?php endforeach; ?>
		</div>

		<?php if ( ! empty( $instance['additional_info'] ) ) : ?>
			<div class="additional-info"><?php echo esc_html( $instance['additional_info'] ); ?></div>
		<?php endif; ?>

	</div>

<?php echo $args['after_widget']; ?>