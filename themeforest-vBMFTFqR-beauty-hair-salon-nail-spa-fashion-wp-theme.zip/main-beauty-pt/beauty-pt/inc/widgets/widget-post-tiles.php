<?php
/**
 * Post Tiles widget
 */

if ( ! class_exists( 'PW_Post_Tiles' ) ) {
	class PW_Post_Tiles extends WP_Widget {

		private $default_layout;
		private $excerpt_limit;
		private $max_post_number = 10;
		private $layout_options  = array(
			'one_post' => array(
				'name'            => 'single post layout',
				'class'           => 'one-post',
				'elements'        => array(
					array( 'size' => 'big', 'class' => 'horizontal', 'content' => array( 'text', 'image' ) ),
				),
			),
			'two_posts_vertical_split' => array(
				'name'            => 'two posts layout with vertical split',
				'class'           => 'two-posts-vertical',
				'elements'        => array(
					array( 'size' => 'medium', 'class' => 'vertical', 'content' => array( 'text', 'image' ) ),
					array( 'size' => 'medium', 'class' => 'vertical', 'content' => array( 'image', 'text' ) ),
				),
			),
			'two_posts_horizontal_split' => array(
				'name'            => 'two posts layout with horizontal split',
				'class'           => 'two-posts-horizontal',
				'elements'        => array(
					array( 'size' => 'medium', 'class' => 'horizontal', 'content' => array( 'text', 'image' ) ),
					array( 'size' => 'medium', 'class' => 'horizontal', 'content' => array( 'image', 'text' ) ),
				),
			),
			'three_posts_bigger_left' => array(
				'name'            => 'three posts layout with bigger post on the left side',
				'class'           => 'three-posts-bigger-left',
				'elements'        => array(
					array( 'size' => 'medium', 'class' => 'vertical', 'content' => array( 'text', 'image' ) ),
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'image', 'text' ) ),
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'text', 'image' ) ),
				),
			),
			'three_posts_bigger_right' => array(
				'name'            => 'three posts layout with bigger post on the right side',
				'class'           => 'three-posts-bigger-right',
				'elements'        => array(
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'text', 'image' ) ),
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'image', 'text' ) ),
					array( 'size' => 'medium', 'class' => 'vertical', 'content' => array( 'text', 'image' ) ),
				),
			),
			'four_posts' => array(
				'name'            => 'four posts layout',
				'class'           => 'four-posts',
				'elements'        => array(
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'text', 'image' ) ),
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'image', 'text' ) ),
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'text', 'image' ) ),
					array( 'size' => 'small', 'class' => 'horizontal', 'content' => array( 'image', 'text' ) ),
				),
			),
		);

		public function __construct() {

			$this->widget_id_base     = 'post_tiles';
			$this->widget_name        = esc_html__( 'Post Tiles', 'beauty-pt' );
			$this->widget_description = esc_html__( 'Widget with single or multiple posts in a tile layout.', 'beauty-pt' );
			$this->widget_class       = 'widget-post-tiles';

			parent::__construct(
				'pw_' . $this->widget_id_base,
				sprintf( 'ProteusThemes: %s', $this->widget_name ),
				array(
					'description' => $this->widget_description,
					'classname'   => $this->widget_class,
				)
			);

			$this->default_layout = apply_filters( 'pw/post_tiles_default_layout', 'one_post' );
			$this->excerpt_limit  = apply_filters( 'pw/post_tiles_excerpt_limit', 120 );
		}

		/**
		 * Front-end display of widget.
		 *
		 * @see WP_Widget::widget()
		 *
		 * @param array $args
		 * @param array $instance
		 */
		public function widget( $args, $instance ) {
			$instance['title']             = empty( $instance['title'] ) ? '' : $args['before_title'] . apply_filters( 'widget_title', $instance['title'], $instance ) . $args['after_title'];
			$instance['selected_layout']   = empty( $instance['selected_layout'] ) ? $this->default_layout : $instance['selected_layout'];
			$instance['start_post_number'] = empty( $instance['start_post_number'] ) ? 1 : $instance['start_post_number'];

			// Get/set cache data just once for multiple widgets
			$prepared_posts = BeautyHelpers::get_cached_posts_data( 'pw_post_tiles_posts', $this->max_post_number + 4 );

			// Counter for current post
			$current_post_counter = $instance['start_post_number'] - 1;

			// Counter for small elements
			$counter_small_elements = 0;

			echo $args['before_widget'];
			?>

			<?php if ( ! empty( $instance['title'] ) ) : ?>
				<div class="post-tiles__widget-title">
					<?php echo $instance['title']; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $instance['more_news'] ) ) : ?>
				<a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="btn  btn-secondary  post-tiles__more-news">
					<?php echo esc_html( $instance['read_more_text'] ); ?>
				</a>
			<?php endif; ?>

			<div class="post-tiles  post-tiles--<?php echo esc_attr( $this->layout_options[ $instance['selected_layout'] ]['class'] ); ?>">
				<?php foreach ( $this->layout_options[ $instance['selected_layout'] ]['elements'] as $element ): ?>
					<?php if ( ( 'small' === $element['size'] ) && ( 0 === $counter_small_elements % 2 ) ) : ?>
						<div class="post-tiles__small-container">
					<?php endif; ?>
						<div class="post-tiles__item  post-tiles__item--<?php echo esc_attr( $element['size'] ); ?>  post-tiles__item--<?php echo esc_attr( $element['class'] ); ?>">
							<?php foreach ( $element['content'] as $content ) : ?>
								<?php if ( 'text' === $content ) : ?>
									<div class="post-tiles__content">
										<div class="post-tiles__date">
											<?php echo esc_html( $prepared_posts[ $current_post_counter ]['date'] ); ?>
										</div>
										<a href="<?php echo esc_url( $prepared_posts[ $current_post_counter ]['link'] ); ?>">
											<h3 class="post-tiles__title"><?php echo wp_kses_post( $prepared_posts[ $current_post_counter ]['title'] ); ?></h3>
										</a>
										<div class="post-tiles__excerpt">
											<?php echo wp_kses_post( wp_trim_words( $prepared_posts[ $current_post_counter ]['excerpt'], $this->excerpt_limit ) ); ?>
										</div>
									</div>
								<?php elseif ( 'image' === $content ) : ?>
									<div class="post-tiles__image">
										<?php if ( ! empty( $prepared_posts[ $current_post_counter ]['image_url'] ) ) : ?>
											<a href="<?php echo esc_url( $prepared_posts[ $current_post_counter ]['link'] ); ?>">
												<img src="<?php echo esc_url( $prepared_posts[ $current_post_counter ]['image_url'] ); ?>" width="<?php echo esc_attr( $prepared_posts[ $current_post_counter ]['image_width'] ); ?>" height="<?php echo esc_attr( $prepared_posts[ $current_post_counter ]['image_height'] ); ?>" srcset="<?php echo esc_attr( $prepared_posts[ $current_post_counter ]['srcset'] ); ?>" sizes="(min-width: 1200px) 554px, (min-width: 992px) 454px, calc(100vw - 30px)" alt="<?php echo esc_attr( $prepared_posts[ $current_post_counter ]['title'] ); ?>">
											</a>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							<?php endforeach; ?>
						</div>
					<?php if ( ( 'small' === $element['size'] ) && ( 1 === $counter_small_elements % 2 ) ) : ?>
						</div>
					<?php endif; ?>
				<?php
						if ( 'small' === $element['size'] ) {
							$counter_small_elements++;
						}
						$current_post_counter++;
					endforeach;
				?>
			</div>

			<?php
			echo $args['after_widget'];
		}

		/**
		 * Sanitize widget form values as they are saved.
		 *
		 * @param array $new_instance The new options
		 * @param array $old_instance The previous options
		 */
		public function update( $new_instance, $old_instance ) {
			$instance = array();

			$instance['title']             = sanitize_text_field( $new_instance['title'] );
			$instance['selected_layout']   = sanitize_text_field( $new_instance['selected_layout'] );
			$instance['start_post_number'] = PW_Functions::bound( $new_instance['start_post_number'], 1, $this->max_post_number );
			$instance['more_news']         = empty( $new_instance['more_news'] ) ? '' : sanitize_key( $new_instance['more_news'] );
			$instance['read_more_text']    = sanitize_text_field( $new_instance['read_more_text'] );

			return $instance;
		}

		/**
		 * Back-end widget form.
		 *
		 * @param array $instance The widget options
		 */
		public function form( $instance ) {
			$title             = ! empty( $instance['title'] ) ? $instance['title'] : '';
			$selected_layout   = ! empty( $instance['selected_layout'] ) ? $instance['selected_layout'] : $this->default_layout;
			$start_post_number = ! empty( $instance['start_post_number'] ) ? $instance['start_post_number'] : 1;
			$more_news         = ! empty( $instance['more_news'] ) ? $instance['more_news'] : '';
			$read_more_text    = ! empty( $instance['read_more_text'] ) ? $instance['read_more_text'] : esc_html__( 'More news', 'beauty-pt' );
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'beauty-pt' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label><?php esc_html_e( 'Select layout:', 'beauty-pt' ); ?></label>
			<div class="post-tiles__layout">
				<?php foreach( $this->layout_options as $key => $option ) : ?>
					<label>
						<input name="<?php echo esc_attr( $this->get_field_name( 'selected_layout' ) ); ?>" type="radio" value="<?php echo esc_attr( $key ); ?>" <?php checked( $selected_layout, $key ); ?> />
						<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/admin/images/' . $key . '.png' ); ?>" alt="<?php echo esc_attr( $option['name'] ); ?>">
					</label>
				<?php endforeach; ?>
			</div>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'start_post_number' ) ); ?>"><?php esc_html_e( 'Start with post number:', 'beauty-pt' ); ?></label>
			<input id="<?php echo esc_attr( $this->get_field_id( 'start_post_number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'start_post_number' ) ); ?>" type="number" value="<?php echo esc_attr( $start_post_number ); ?>" />
			<br>
			<small><?php esc_html_e( 'Input limit: 1 to 10. Enter 1, if you want to display the most recent posts.', 'beauty-pt' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'more_news' ) ); ?>"><?php esc_html_e( 'Show more news button:', 'beauty-pt' ); ?></label>
			<input id="<?php echo esc_attr( $this->get_field_id( 'more_news' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_news' ) ); ?>" type="checkbox" <?php checked( $more_news, 'on' ); ?> />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'read_more_text' ) ); ?>"><?php esc_html_e( 'Read more button text:', 'beauty-pt' ); ?></label>
			<input id="<?php echo esc_attr( $this->get_field_id( 'read_more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'read_more_text' ) ); ?>" type="text" value="<?php echo esc_attr( $read_more_text ); ?>" />
		</p>

		<?php
		}

	}
	register_widget( 'PW_Post_Tiles' );
}