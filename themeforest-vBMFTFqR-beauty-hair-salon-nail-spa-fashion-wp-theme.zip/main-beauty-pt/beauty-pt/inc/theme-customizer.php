<?php
/**
 * Load the Customizer with some custom extended addons
 *
 * @package Beauty
 * @link http://codex.wordpress.org/Theme_Customization_API
 */

/**
 * This funtion is only called when the user is actually on the customizer page
 * @param  WP_Customize_Manager $wp_customize
 */
if ( ! function_exists( 'beauty_customizer' ) ) {
	function beauty_customizer( $wp_customize ) {
		// add required files
		BeautyHelpers::load_file( '/inc/customizer/class-customize-base.php' );

		new Beauty_Customizer_Base( $wp_customize );
	}
	add_action( 'customize_register', 'beauty_customizer' );
}


/**
 * Takes care for the frontend output from the customizer and nothing else
 */
if ( ! function_exists( 'beauty_customizer_frontend' ) && ! class_exists( 'Beauty_Customize_Frontent' ) ) {
	function beauty_customizer_frontend() {
		BeautyHelpers::load_file( '/inc/customizer/class-customize-frontend.php' );
		$beauty_customize_frontent = new Beauty_Customize_Frontent();
	}
	add_action( 'init', 'beauty_customizer_frontend' );
}
