<?php
/**
 * Register automatic updates for this theme.
 */

use ProteusThemes\ThemeRegistration\ThemeRegistration;

class BeautyThemeRegistration {
	function __construct() {
		$this->enable_theme_registration();
	}

	/**
	 * Load theme registration and automatic updates.
	 */
	private function enable_theme_registration() {
		$config = array(
			'item_name'        => 'Beauty',
			'theme_slug'       => 'beauty-pt',
			'item_id'          => 2799,
			'tf_item_id'       => 14458185,
			'customizer_panel' => 'panel_beauty',
			'build'            => 'tf',
		);
		$pt_theme_registration = ThemeRegistration::get_instance( $config );
	}
}

if ( ! BEAUTY_DEVELOPMENT && ! defined( 'ENVATO_HOSTED_SITE' ) ) {
	$beauty_theme_registration = new BeautyThemeRegistration();
}
