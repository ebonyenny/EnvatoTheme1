<?php

/*
 *  Beauty About Template for Visual Composer
 */

add_action( 'vc_load_default_templates_action','beauty_about_template_for_vc' );

function beauty_about_template_for_vc() {
	$data               = array();
	$data['name']       = sprintf( 'Beauty: %s', __( 'About Us', 'beauty-pt' ) );
	$data['image_path'] = preg_replace( '/\s/', '%20', get_template_directory_uri() . '/vendor/proteusthemes/visual-composer-elements/assets/images/pt.svg' );
	$data['custom_class'] = 'beauty_about_template_for_vc_custom_template';
	$data['content']    = <<<CONTENT
		[vc_row css=".vc_custom_1453121984664{margin-bottom: 70px !important;}"][vc_column width="1/2"][vc_single_image image="349" img_size="full"][/vc_column][vc_column width="1/4"][vc_column_text]
		<h4>Our Salon</h4>
		The ultra comfortable, modern and pleasant ambience adds to the aesthetics. Salon is well equiped and functional for any hairstyle you wish.[/vc_column_text][vc_column_text]
		<h4 style="text-align: left;">Our Mission</h4>
		<div>For those looking for top notch service and the latest hair trends and style best suited for you.</div>
		[/vc_column_text][/vc_column][vc_column width="1/4"][vc_column_text]
		<h4>Our Vision</h4>
		<div>With the latest technology and equipments at their disposal, they not only. Our vision is happy costumer who comes back.</div>
		[/vc_column_text][vc_column_text]
		<h4 style="text-align: left;">Our Goals</h4>
		<div>We realize our salon’s goals and mission of being the right place from where you looking.</div>
		[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1453122111296{margin-bottom: 56px !important;}"][vc_column][vc_column_text]
		<h3 class="widget-title"><span class="widget-title__inline">Our Team</span></h3>
		[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1453122177645{margin-bottom: 65px !important;}"][vc_column width="1/3"][pt_vc_person_profile name="Philip Fernandezes" title="Hairdresser" image_url="http://xml-io.proteusthemes.com/beauty/wp-content/uploads/sites/29/2016/01/team1.jpg" introduction="A 20 year veteran in the beauty industry, Philip has worked in New York in shaping and cutting hair with a passion for dry-hair cutting." social_links="https://www.facebook.com/ProteusThemes|fa-facebook
		https://twitter.com/proteusthemes|fa-twitter
		https://www.youtube.com/user/ProteusNetCompany/|fa-youtube"][/vc_column][vc_column width="1/3"][pt_vc_person_profile name="Gianni De Michel" title="Hair Stylist" image_url="http://xml-io.proteusthemes.com/beauty/wp-content/uploads/sites/29/2016/01/team2.jpg" introduction="He has displayed artistic talents at world renowned salons in London, Paris and Milan. In 90s he was personal stylist of Pamela Anderson." social_links="https://www.facebook.com/ProteusThemes|fa-facebook
		https://twitter.com/proteusthemes|fa-twitter
		https://www.youtube.com/user/ProteusNetCompany/|fa-youtube"][/vc_column][vc_column width="1/3"][pt_vc_person_profile name="Valentina Konig" title="Hair Coloring Technician" image_url="http://xml-io.proteusthemes.com/beauty/wp-content/uploads/sites/29/2016/01/team3.jpg" introduction="Trained under her aunt Victoria Konig's guidance and is an internationally acclaimed celebrity colouring technician." social_links="https://www.facebook.com/ProteusThemes|fa-facebook
		https://twitter.com/proteusthemes|fa-twitter
		https://www.youtube.com/user/ProteusNetCompany/|fa-youtube"][/vc_column][/vc_row][vc_row css=".vc_custom_1453122219195{margin-bottom: 56px !important;}"][vc_column][vc_column_text]
		<h3 class="widget-title"><span class="widget-title__inline">Open Positions</span></h3>
		[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1453122255886{margin-bottom: 0px !important;}"][vc_column width="1/2"][pt_vc_open_position details_title="Creative Stylist" detail_items="227 Marin Street Avenue Columbia SC 29201|fa-home
		info@hairpress.com|fa-inbox
		CV - Letter of Application|fa-folder-open"]
		<div>

		In order to ensure utmost perfection, we will have a 2 hour long trial w here we will discuss what you want, your ideas and what are you planning to wear. We will together discover looks that w ill enhance your beauty and complete your look. We ensure that the agreed look will be practiced and offer a realistic vis ualization.

		</div>
		<!--more-->
		<div>With years of experience and using the best make-up and skincare products available in the market, we can ensure that your makeup is stunning and is exactly the way you want it to be.  Whether you are looking for a quick beach side gateway or a pampering day for yourself, we have spa treatments to meet your needs. All of our spa treatments are specially designed for restorative, recovery and relaxation.</div>
		[/pt_vc_open_position][/vc_column][vc_column width="1/2"][pt_vc_open_position details_title="Blowdry Specialist" detail_items="Blowdry Specialist|fa-briefcase
		info@hairpress.com|fa-inbox
		CV - Letter of Application|fa-folder-open"]
		<div>

		Be it a red carpet occasion or a special event in your life like prom nights, special date nights, anniversaries or any other special occasions, you can be confident of your looks with our hair styling experts. We offer a wide range of all imaginable.

		</div>
		<!--more-->
		<div>All of our massage treatments incorporates disciplines of muscle manipulation and relaxation. These massage treatments are designed to relieve stress and tension. If you are unsure which treatment is best suited for you, you can consult out therapists who can recommend the best one for you.</div>
		[/pt_vc_open_position][/vc_column][/vc_row]
CONTENT;

	vc_add_default_templates( $data );
}