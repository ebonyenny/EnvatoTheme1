<?php

/*
 *  Beauty Contact Template for Visual Composer
 */

add_action( 'vc_load_default_templates_action','beauty_contact_template_for_vc' );

function beauty_contact_template_for_vc() {
	$data               = array();
	$data['name']       = sprintf( 'Beauty: %s', __( 'Contact Us', 'beauty-pt' ) );
	$data['image_path'] = preg_replace( '/\s/', '%20', get_template_directory_uri() . '/vendor/proteusthemes/visual-composer-elements/assets/images/pt.svg' );
	$data['custom_class'] = 'beauty_contact_template_for_vc_custom_template';
	$data['content']    = <<<CONTENT
		[vc_row full_width="stretch_row_content_no_spaces" css=".vc_custom_1453123084859{margin-top: -80px !important;margin-bottom: 70px !important;}"][vc_column][vc_gmaps link="#E-8_JTNDaWZyYW1lJTIwc3JjJTNEJTIyaHR0cHMlM0ElMkYlMkZ3d3cuZ29vZ2xlLmNvbSUyRm1hcHMlMkZlbWJlZCUzRnBiJTNEJTIxMW0xOCUyMTFtMTIlMjExbTMlMjExZDYzMDQuODI5OTg2MTMxMjcxJTIxMmQtMTIyLjQ3NDY5NjgwMzMwOTIlMjEzZDM3LjgwMzc0NzUyMTYwNDQzJTIxMm0zJTIxMWYwJTIxMmYwJTIxM2YwJTIxM20yJTIxMWkxMDI0JTIxMmk3NjglMjE0ZjEzLjElMjEzbTMlMjExbTIlMjExczB4ODA4NTg2ZTYzMDI2MTVhMSUyNTNBMHg4NmJkMTMwMjUxNzU3YzAwJTIxMnNTdG9yZXklMkJBdmUlMjUyQyUyQlNhbiUyQkZyYW5jaXNjbyUyNTJDJTJCQ0ElMkI5NDEyOSUyMTVlMCUyMTNtMiUyMTFzZW4lMjEyc3VzJTIxNHYxNDM1ODI2NDMyMDUxJTIyJTIwd2lkdGglM0QlMjI2MDAlMjIlMjBoZWlnaHQlM0QlMjI0NTAlMjIlMjBmcmFtZWJvcmRlciUzRCUyMjAlMjIlMjBzdHlsZSUzRCUyMmJvcmRlciUzQTAlMjIlMjBhbGxvd2Z1bGxzY3JlZW4lM0UlM0MlMkZpZnJhbWUlM0U=" size="300"][/vc_column][/vc_row][vc_row css=".vc_custom_1453123138712{margin-bottom: 56px !important;}"][vc_column][vc_column_text]
		<h3 class="widget-title"><span class="widget-title__inline">Info</span></h3>
		[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1453123165130{margin-bottom: 0px !important;}"][vc_column width="1/4"][vc_column_text css=".vc_custom_1453123016385{padding: 40px !important;background-color: #f2f2f2 !important;}"]<strong><span style="color: #333333;">HairPress inc.</span></strong>
		227 Marin Street Avenue
		Columbia, SC 29201
		United Kingdom

		1-888-123-4567
		1-234-567-8900

		info@hairpress.com[/vc_column_text][pt_vc_opening_time days_hours="opened|8:00|16:00
		opened|8:00|16:00
		opened|8:00|16:00
		opened|8:00|16:00
		opened|8:00|16:00
		opened|8:00|16:00
		closed"][/vc_column][vc_column width="3/4"][contact-form-7 id="30"][/vc_column][/vc_row]
CONTENT;

	vc_add_default_templates( $data );
}