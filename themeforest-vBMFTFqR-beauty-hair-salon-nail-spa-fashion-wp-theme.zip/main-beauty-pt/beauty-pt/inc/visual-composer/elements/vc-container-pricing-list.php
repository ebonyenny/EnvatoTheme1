<?php

/**
 * Pricing list container content element for the Visual Composer editor,
 * that allows nesting of the Pricing list item VC content element
 */

if ( ! class_exists( 'PT_VC_Container_Pricing_List' ) ) {
	class PT_VC_Container_Pricing_List extends PT_VC_Shortcode {

		// Basic shortcode settings
		function shortcode_name() { return 'pt_vc_container_pricing_list'; }

		// Initialize the shortcode by calling the parent constructor
		public function __construct() {
			parent::__construct();
		}

		// Overwrite the register_shortcode function from the parent class
		public function register_shortcode( $atts, $content = null ) {
			$atts = shortcode_atts( array(
				'widget_title'         => '',
				), $atts );

			$items = PT_VC_Helper_Functions::get_child_elements_data( $content );

			$instance = array(
				'widget_title' => $atts['widget_title'],
				'items'        => $items,
			);

			ob_start();
				the_widget( 'PW_Pricing_List', $instance );
			return ob_get_clean();
		}

		// Overwrite the vc_map_shortcode function from the parent class
		public function vc_map_shortcode() {
			vc_map( array(
				'name'            => __( 'Pricing List', 'beauty-pt' ),
				'base'            => $this->shortcode_name(),
				'category'        => __( 'Content', 'beauty-pt' ),
				'icon'            => get_template_directory_uri() . '/vendor/proteusthemes/visual-composer-elements/assets/images/pt.svg',
				'as_parent'       => array( 'only' => 'pt_vc_pricing_list' ),
				'content_element' => true,
				'js_view'         => 'VcColumnView',
				'params'          => array(
					array(
						'type'       => 'textfield',
						'holder'     => 'div',
						'heading'    => __( 'Title', 'beauty-pt' ),
						'param_name' => 'widget_title',
					),
				)
			) );
		}
	}

	// Initialize the class
	new PT_VC_Container_Pricing_List;

	// The "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		class WPBakeryShortCode_Pt_Vc_Container_Pricing_List extends WPBakeryShortCodesContainer {}
	}
}