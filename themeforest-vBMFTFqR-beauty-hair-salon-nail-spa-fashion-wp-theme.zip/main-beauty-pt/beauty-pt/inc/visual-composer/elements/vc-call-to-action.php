<?php

/**
 * Call to Action content element for the Visual Composer editor
 */

if ( ! class_exists( 'PT_VC_Call_To_Action' ) ) {
	class PT_VC_Call_To_Action extends PT_VC_Shortcode {

		// Basic shortcode settings
		function shortcode_name() { return 'pt_vc_call_to_action'; }

		// Initialize the shortcode by calling the parent constructor
		public function __construct() {
			parent::__construct();
		}

		// Overwrite the register_shortcode function from the parent class
		public function register_shortcode( $atts, $content = null ) {
			$atts = shortcode_atts( array(
				'title'    => 'Book your visit online and save up to -30%',
				'subtitle' => 'First 100 booking will be awarded with free Thai massage',
				), $atts );

			$instance = array(
				'title'       => $atts['title'],
				'subtitle'    => $atts['subtitle'],
				'button_text' => $content,
			);

			ob_start();
			the_widget( 'PW_Call_To_Action', $instance );
			return ob_get_clean();
		}

		// Overwrite the vc_map_shortcode function from the parent class
		public function vc_map_shortcode() {
			vc_map( array(
				'name'     => __( 'Call to Action', 'beauty-pt' ),
				'base'     => $this->shortcode_name(),
				'category' => __( 'Content', 'beauty-pt' ),
				'icon'     => get_template_directory_uri() . '/vendor/proteusthemes/visual-composer-elements/assets/images/pt.svg',
				'params'   => array(
					array(
						'type'       => 'textfield',
						'holder'     => 'div',
						'heading'    => __( 'Title:', 'beauty-pt' ),
						'param_name' => 'title',
					),
					array(
						'type'       => 'textfield',
						'holder'     => 'div',
						'heading'    => __( 'Subtitle:', 'beauty-pt' ),
						'param_name' => 'subtitle',
					),
					array(
						'type'        => 'textarea_html',
						'class'       => '',
						'heading'     => __( 'Button Area:', 'beauty-pt' ),
						'param_name'  => 'content',
						'description' => sprintf( _x( 'Input a button shortcode in the above field. Please take a look at the <a href="%1$s" target="_blank">Buttons Shortcode documentation</a> to learn more on how to write button shortcodes.', 'Preserve the HTML tags in the translated text.', 'beauty-pt' ), 'https://www.proteusthemes.com/docs/beauty-pt/#buttons' ),
					),
				)
			) );
		}
	}

	// Initialize the class
	new PT_VC_Call_To_Action;
}