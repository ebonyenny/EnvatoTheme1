<?php

/**
 * Post tiles content element for the Visual Composer editor
 */

if ( ! class_exists( 'PT_VC_Post_Tiles' ) ) {
	class PT_VC_Post_Tiles extends PT_VC_Shortcode {

		// Basic shortcode settings
		function shortcode_name() { return 'pt_vc_post_tiles'; }

		// Initialize the shortcode by calling the parent constructor
		public function __construct() {
			parent::__construct();
		}

		// Overwrite the register_shortcode function from the parent class
		public function register_shortcode( $atts, $content = null ) {
			$atts = shortcode_atts( array(
				'title'             => '',
				'selected_layout'   => 'one_post',
				'start_post_number' => 1,
				'more_news'         => '',
				'read_more_text'    => 'More news',
				), $atts );

			ob_start();
			the_widget( 'PW_Post_Tiles', $atts );
			return ob_get_clean();
		}

		// Overwrite the vc_map_shortcode function from the parent class
		public function vc_map_shortcode() {
			vc_map( array(
				'name'     => __( 'Post Tiles', 'beauty-pt' ),
				'base'     => $this->shortcode_name(),
				'category' => __( 'Content', 'beauty-pt' ),
				'icon'     => get_template_directory_uri() . '/vendor/proteusthemes/visual-composer-elements/assets/images/pt.svg',
				'params'   => array(
					array(
						'type'       => 'textfield',
						'holder'     => 'div',
						'heading'    => __( 'Title:', 'beauty-pt' ),
						'param_name' => 'title',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Select layout:', 'beauty-pt' ),
						'param_name'  => 'selected_layout',
						'value'       => array(
							__( 'Single post', 'beauty-pt' )                          => 'one_post',
							__( 'Two posts with vertical split', 'beauty-pt' )        => 'two_posts_vertical_split',
							__( 'Two posts with horizontal split', 'beauty-pt' )      => 'two_posts_horizontal_split',
							__( 'Three posts with bigger on the left', 'beauty-pt' )  => 'three_posts_bigger_left',
							__( 'Three posts with bigger on the right', 'beauty-pt' ) => 'three_posts_bigger_right',
							__( 'Four posts', 'beauty-pt' )                           => 'four_posts',
						),
					),
					array(
						'type'        => 'input_number',
						'heading'     => __( 'Start with post number:', 'beauty-pt' ),
						'description' => __( 'Input limit: 1 to 10. Enter 1, if you want to display the most recent posts.', 'beauty-pt' ),
						'param_name'  => 'start_post_number',
						'min'         => 1,
						'max'         => 10,
						'value'       => 1,
					),
					array(
						'type'       => 'checkbox',
						'heading'    => __( 'Show more news button:', 'beauty-pt' ),
						'param_name' => 'more_news',
					),
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Read more button text:', 'beauty-pt' ),
						'param_name' => 'read_more_text',
						'value'      => 'More news',
					),
				)
			) );
		}
	}

	// Initialize the class
	new PT_VC_Post_Tiles;
}