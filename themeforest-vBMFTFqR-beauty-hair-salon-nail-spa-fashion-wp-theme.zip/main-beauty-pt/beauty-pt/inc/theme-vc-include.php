<?php

// Only require these files, if the Visual Composer plugin is activated
if ( defined( 'WPB_VC_VERSION' ) ) {

	// Require Visual Composer classes
	require_once get_template_directory() . '/vendor/proteusthemes/visual-composer-elements/vc-shortcodes/class-vc-shortcode.php';
	require_once get_template_directory() . '/vendor/proteusthemes/visual-composer-elements/vc-shortcodes/class-vc-custom-param-types.php';
	require_once get_template_directory() . '/vendor/proteusthemes/visual-composer-elements/vc-shortcodes/class-vc-helpers.php';

	// Require Visual Composer Beauty front page template
	BeautyHelpers::load_file( '/inc/visual-composer/templates/vc-home-page-template.php' );
	BeautyHelpers::load_file( '/inc/visual-composer/templates/vc-our-services-template.php' );
	BeautyHelpers::load_file( '/inc/visual-composer/templates/vc-who-we-are-template.php' );
	BeautyHelpers::load_file( '/inc/visual-composer/templates/vc-contact-us-template.php' );

	// Require custom VC elements for Beauty theme
	BeautyHelpers::load_file( '/inc/visual-composer/elements/vc-call-to-action.php' );
	BeautyHelpers::load_file( '/inc/visual-composer/elements/vc-open-position.php' );
	BeautyHelpers::load_file( '/inc/visual-composer/elements/vc-post-tiles.php' );
	BeautyHelpers::load_file( '/inc/visual-composer/elements/vc-pricing-list.php' );
	BeautyHelpers::load_file( '/inc/visual-composer/elements/vc-container-pricing-list.php' );

	// Visual Composer shortcodes for the theme from the Visual Composer Elements (PHP Composer package)
	$beauty_custom_vc_shortcodes = array(
		'brochure-box',
		'facebook',
		'featured-page',
		'icon-box',
		'skype',
		'opening-time',
		'social-icon',
		'container-social-icons',
		'testimonial',
		'container-testimonials',
		'accordion-item',
		'container-accordion',
		'person-profile',
	);

	foreach ( $beauty_custom_vc_shortcodes as $file ) {
		BeautyHelpers::load_file( sprintf( '/vendor/proteusthemes/visual-composer-elements/vc-shortcodes/shortcodes/vc-%s.php', $file ) );
	}
}