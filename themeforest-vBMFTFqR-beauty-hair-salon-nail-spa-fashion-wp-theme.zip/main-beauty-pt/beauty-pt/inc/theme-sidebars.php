<?php
/**
 * Register sidebars for Beauty
 *
 * @package Beauty
 */

function beauty_sidebars() {
	// Blog Sidebar
	register_sidebar(
		array(
			'name'          => esc_html_x( 'Blog Sidebar', 'backend', 'beauty-pt' ),
			'id'            => 'blog-sidebar',
			'description'   => esc_html_x( 'Sidebar on the blog layout.', 'backend', 'beauty-pt' ),
			'class'         => 'blog  sidebar',
			'before_widget' => '<div class="widget  %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="sidebar__headings">',
			'after_title'   => '</h4>',
		)
	);

	// Regular Page Sidebar
	register_sidebar(
		array(
			'name'          => esc_html_x( 'Regular Page Sidebar', 'backend', 'beauty-pt' ),
			'id'            => 'regular-page-sidebar',
			'description'   => esc_html_x( 'Sidebar on the regular page.', 'backend', 'beauty-pt' ),
			'class'         => 'sidebar',
			'before_widget' => '<div class="widget  %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="sidebar__headings">',
			'after_title'   => '</h4>',
		)
	);

	// Top Left Widgets
	register_sidebar(
		array(
			'name'          => esc_html_x( 'Top Left', 'backend', 'beauty-pt' ),
			'id'            => 'top-left-widgets',
			'description'   => esc_html_x( 'Top left widget area for Icon Box, Social Icons, Custom Menu or Text widget.', 'backend', 'beauty-pt' ),
			'before_widget' => '<div class="widget  %2$s">',
			'after_widget'  => '</div>',
		)
	);

	// Top Right Widgets
	register_sidebar(
		array(
			'name'          => esc_html_x( 'Top Right', 'backend', 'beauty-pt' ),
			'id'            => 'top-right-widgets',
			'description'   => esc_html_x( 'Top right widget area for Icon Box, Social Icons, Custom Menu or Text widget.', 'backend', 'beauty-pt' ),
			'before_widget' => '<div class="widget  %2$s">',
			'after_widget'  => '</div>',
		)
	);

	// Header Left Widgets - register only if the the header layout is set to center
	if ( 'center-logo' === get_theme_mod( 'header_layout', 'left-logo' ) ) {
		register_sidebar(
			array(
				'name'          => esc_html_x( 'Header Left', 'backend', 'beauty-pt' ),
				'id'            => 'header-left-widgets',
				'description'   => esc_html_x( 'Header left widget area for Buttons, Icon Box, Social Icons, Skype Button or Search widget.', 'backend', 'beauty-pt' ),
				'before_widget' => '<div class="widget  %2$s">',
				'after_widget'  => '</div>',
			)
		);
	}

	// Header Right Widgets
	register_sidebar(
		array(
			'name'          => esc_html_x( 'Header Right', 'backend', 'beauty-pt' ),
			'id'            => 'header-right-widgets',
			'description'   => esc_html_x( 'Header right widget area for Buttons, Icon Box, Social Icons, Skype Button or Search widget.', 'backend', 'beauty-pt' ),
			'before_widget' => '<div class="widget  %2$s">',
			'after_widget'  => '</div>',
		)
	);

	// Navigation Widgets
	register_sidebar(
		array(
			'name'          => esc_html_x( 'Navigation', 'backend', 'beauty-pt' ),
			'id'            => 'navigation-widgets',
			'description'   => esc_html_x( 'Navigation widget area for Social Icons, Icon Box, Buttons or Search widget.', 'backend', 'beauty-pt' ),
			'before_widget' => '<div class="widget  %2$s">',
			'after_widget'  => '</div>',
		)
	);

	// woocommerce shop sidebar
	if ( BeautyHelpers::is_woocommerce_active() ) {
		register_sidebar(
			array(
				'name'          => esc_html_x( 'Shop Sidebar', 'backend' , 'beauty-pt' ),
				'id'            => 'shop-sidebar',
				'description'   => esc_html_x( 'Sidebar for the shop page', 'backend' , 'beauty-pt' ),
				'class'         => 'sidebar',
				'before_widget' => '<div class="widget  %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h4 class="sidebar__headings">',
				'after_title'   => '</h4>',
			)
		);
	}

	// Footer
	$footer_widgets_num = count( BeautyHelpers::footer_widgets_layout_array() );

	// only register if not 0
	if ( $footer_widgets_num > 0 ) {
		register_sidebar(
			array(
				'name'          => esc_html_x( 'Footer', 'backend', 'beauty-pt' ),
				'id'            => 'footer-widgets',
				'description'   => sprintf( esc_html_x( 'Footer area works best with %d widgets. This number can be changed in the Appearance &rarr; Customize &rarr; Theme Options &rarr; Footer.', 'backend', 'beauty-pt' ), $footer_widgets_num ),
				'before_widget' => '<div class="col-xs-12  col-lg-__col-num__"><div class="widget  %2$s">', // __col-num__ is replaced dynamically in filter 'dynamic_sidebar_params'
				'after_widget'  => '</div></div>',
				'before_title'  => '<h6 class="footer-top__headings">',
				'after_title'   => '</h6>',
			)
		);
	}
}
add_action( 'widgets_init', 'beauty_sidebars' );