# Beauty WordPress theme

Premium WordPress theme by [ProteusThemes](http://www.proteusthemes.com/). For support please visit [our support platform](http://support.proteusthemes.com/).