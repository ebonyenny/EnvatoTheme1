/**
 * Post Tiles Widget
 */
define( ['jquery', 'underscore'], function( $, _ ){
	'use strict';

	var config = {
		dateElementClass:    '.post-tiles__date',
		titleElementClass:   '.post-tiles__title',
		excerptElementClass: '.post-tiles__excerpt',
	};

	var PostTiles = function( $itemContent ){
		this.$itemContent = $itemContent;

		this.registerListeners();

		$( window ).trigger( 'resize' );

		return this;
	};

	_.extend( PostTiles.prototype, {
		/**
		 * Register DOM listeners (resize event)
		 */
		registerListeners: function () {
			$( window ).resize( _.debounce( _.bind( function() {
				this.setExcerptHeight();
				this.shortenExcerpt();
			}, this ) , 100 ) );

			return this;
		},

		/**
		 * Set the excerpt div height (destroy dotdotdot instance on the excerpt element, if it already exists)
		 */
		setExcerptHeight: function () {
			this.destroyDotDotDot();
			this.getExcerptElement().css( 'height', this.calculateExcerptHeight() );

			return this;
		},

		/**
		 * Returns the jQuery object of the excerpt element
		 */
		getExcerptElement: function () {
			return this.$itemContent.children( config.excerptElementClass );
		},

		/**
		 * Returns the calculated height for the excerpt element:
		 * Content height (without the padding) - date height - title height
		 * Also reset the height of the excerpt element
		 */
		calculateExcerptHeight: function () {
			this.resetExcerptHeight();
			return Math.round( this.$itemContent.height() - this.getElementHeight( config.dateElementClass ) - this.getElementHeight( config.titleElementClass ) );
		},

		/**
		 * Returns the height of the date element
		 */
		getElementHeight: function ( selector ) {
			return this.$itemContent.find( selector ).outerHeight( true );
		},

		/**
		 * Removes the CSS height property from the excerpt element
		 */
		resetExcerptHeight: function () {
			this.getExcerptElement().css( 'height', '' );
		},

		/**
		 * Shorten PostTiles excerpts to a proper size
		 */
		shortenExcerpt: function () {
			this.getExcerptElement().dotdotdot();

			return this;
		},

		/**
		 * Destroy the dotdotdot instance from the excerpt element
		 */
		destroyDotDotDot: function () {
			this.getExcerptElement().trigger('destroy.dot');

			return this;
		}
	});

	return PostTiles;
});