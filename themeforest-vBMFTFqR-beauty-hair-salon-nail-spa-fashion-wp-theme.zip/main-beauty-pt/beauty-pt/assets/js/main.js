/* global BeautySliderCaptions, BeautyVars */

// config
require.config( {
	paths: {
		jquery:     'assets/js/fix.jquery',
		underscore: 'assets/js/fix.underscore',
		util:       'bower_components/bootstrap/dist/js/umd/util',
		alert:      'bower_components/bootstrap/dist/js/umd/alert',
		button:     'bower_components/bootstrap/dist/js/umd/button',
		carousel:   'bower_components/bootstrap/dist/js/umd/carousel',
		collapse:   'bower_components/bootstrap/dist/js/umd/collapse',
		dropdown:   'bower_components/bootstrap/dist/js/umd/dropdown',
		modal:      'bower_components/bootstrap/dist/js/umd/modal',
		scrollspy:  'bower_components/bootstrap/dist/js/umd/scrollspy',
		tab:        'bower_components/bootstrap/dist/js/umd/tab',
		tooltip:    'bower_components/bootstrap/dist/js/umd/tooltip',
		popover:    'bower_components/bootstrap/dist/js/umd/popover',
		stampit:    'assets/js/vendor/stampit',
	},
} );

require.config( {
	baseUrl: BeautyVars.pathToTheme
} );

require( [
		'jquery',
		'underscore',
		'assets/js/utils/isElementInView',
		'assets/js/PostTiles',
		'assets/js/utils/objectFitFallback',
		'assets/js/StickyNavbar',
		'assets/js/TouchDropdown',
		'carousel',
		'collapse',
		'tab',
], function ( $, _, isElementInView, PostTiles, objectFitFallback ) {
	'use strict';

	/**
	 * Footer widgets fix
	 */
	$( '.col-lg-__col-num__' ).removeClass( 'col-lg-__col-num__' ).addClass( 'col-lg-3' );

	/**
	 * Post Tiles Widget - dynamically change the excerpt lengths
	 */
	$('.post-tiles__content').each(function () {
		new PostTiles( $(this) );
	});

	/**
	 * Post tyles - fallback for old browsers
	 * @return {[type]} [description]
	 */
	(function () {
		if ( ! Modernizr.objectfit ) {
			// post tiles
			$('.post-tiles__image').each(function () {
				objectFitFallback({
					$container: $(this)
				});
			});

			// gallery
			$('.beauty-gallery__item').each(function () {
				objectFitFallback({
					$container: $(this)
				});
			});
		}
	})();



	/**
	 * Animate the scroll, when back to top is clicked
	 */
	(function backToTop() {
		$('.footer-middle__back-to-top').click(function (ev) {
			ev.preventDefault();

			$('body, html').animate({
				scrollTop: 0
			}, 700);
		});
	})();

	/**
	 * Main slider controls
	 */
	(function slider () {
		var $slider = $('.js-jumbotron-slider'),
			$captions = {
				container: $('.js-slider-captions'),
				title:     $('.js-slider-captions__title'),
				text:      $('.js-slider-captions__text'),
			},
			transitionClass = 'is-in-transition',
			transitionTime = 600; // in ms

		// Captions for the main slider - change them in the out-of-the-bounds element
		if ( $slider.length && 'object' === typeof BeautySliderCaptions ) {
			$slider.on('slide.bs.carousel', function (ev) {
				var nextIndex = $(ev.relatedTarget).index();

				$captions.container.addClass(transitionClass);

				setTimeout(_.bind(function () {
					$captions.title.text(BeautySliderCaptions[nextIndex].title);
					$captions.text.html(BeautySliderCaptions[nextIndex].text);
				}, this), (transitionTime / 2));
			});

			$slider.on('slid.bs.carousel', function () {
				$captions.container.removeClass(transitionClass);
			});
		}

		// Pause the carousel if it's not visible
		if ($slider.length) {
			$(document).on('scroll', _.throttle(function () {
				if (isElementInView($slider)) {
					$slider.carousel('cycle');
				}
				else {
					$slider.carousel('pause');
				}
			}, 1000, {leading: false}));
		}
	})();

} );
